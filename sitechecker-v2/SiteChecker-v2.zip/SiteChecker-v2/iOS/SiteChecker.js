// Variables used by Scriptable.
// icon-color: deep-green; icon-glyph: globe;
// SiteChecker v2 — native local requests, keep foreground.
// Shared pure logic. URL and DOMParser are evaluated only inside an inert WebView.
function createCore(){
 const reachable=k=>['usable','login','js'].includes(k);
 const allNetwork=(a,n)=>a.length>=n&&a.every(x=>x.kind==='transport');
 function normalize(raw){
  let s=String(raw).trim().replace(/^\ufeff/,'');
  if(!/^[a-z][a-z0-9+.-]*:\/\//i.test(s)){
   if(!/^(localhost|[a-z0-9\u3400-\u9fff][a-z0-9.\-\u3400-\u9fff]*\.[a-z\u3400-\u9fff]{2,}|[0-9]+(?:\.[0-9]+){3}|\[[0-9a-f:]+\])(?::[0-9]{1,5})?(?:[/\?#][^\s]*)?$/i.test(s))throw Error('请输入完整网址或有效域名');
   s='https://'+s;
  }
  const u=new URL(s);if(!['http:','https:'].includes(u.protocol)||!u.hostname||u.username||u.password||/\s/.test(u.host)||u.port==='0')throw Error('网址无效，仅支持无账号密码的 HTTP/HTTPS');
  return u.href;
 }
 function parseList(text){
  const rows=[];for(const raw of text.replace(/\r\n/g,'\n').split('\n')){
   const line=raw.trim().replace(/^\ufeff/,'');if(!line)continue;let candidates=[line],extracted=false;
   try{normalize(line)}catch(e){if(line.includes('](')||(!/^[a-z][a-z0-9+.-]*:\/\//i.test(line)&&/[ \t]/.test(line))){const found=line.match(/https?:\/\/[^\s<>"`|]+/gi);if(found){candidates=found;extracted=true}}}
   for(let candidate of candidates){if(extracted&&line.includes(']('))candidate=candidate.replace(/\)$/,'');const r={input:line,url:'',direct:[],proxy:[],recheck:[]};try{r.url=normalize(candidate)}catch(e){r.error=String(e.message||e)}rows.push(refresh(r))}
  }return rows;
 }
 function classify(ctype,path,body,truncated){
  const result=(kind,note,title='')=>({kind,note:note+(truncated?'；仅分析响应前部':''),title,truncated});
  if(!body.trim())return result('empty','空响应，需复核');
  if(!/html/i.test(ctype)&&!/<(?:html|body|!doctype html)\b/i.test(body))return result('usable','已获得响应内容');
  // Detached parsed DOM. Never attach target HTML or run its scripts.
  const d=new DOMParser().parseFromString(body,'text/html');const title=(d.title||'').replace(/\s+/g,' ').trim();
  const script=!!d.querySelector('script');const login=!!d.querySelector('input[type="password" i]')||/\/(?:login|signin|sign-in)(?:\/|$)/i.test(path);
  const challenge=Array.from(d.querySelectorAll('[src],[id],[class]')).some(el=>['src','id','class'].some(k=>{const s=(el.getAttribute(k)||'').toLowerCase();return s.includes('/cdn-cgi/challenge-platform/')||s.startsWith('cf-chl-')}));
  d.querySelectorAll('script,style,head,noscript,template').forEach(n=>n.remove());const visible=(d.body?.textContent||'').replace(/\s+/g,' ').trim();
  if(challenge||/^(?:just a moment[.!… ]*|attention required.*|access denied[.! ]*|verify you are human.*|security verification.*|robot check.*|安全验证.*|人机验证.*|访问受限.*|访问验证.*|访问被拒绝.*)$/i.test(title)||/^(?:checking your browser before accessing|please enable javascript and cookies to continue|the requested url was rejected|网站已被拦截|该网站暂时无法访问)/i.test(visible))return result('challenge','服务器返回验证 / 拦截页面，需人工确认',title);
  if(/^(?:(?:error\s*)?(?:403|404|500|502|503|504)\b.*|service unavailable.*|temporarily unavailable.*|internal server error.*|bad gateway.*|gateway timeout.*|page not found.*|服务不可用.*|系统维护.*|网站维护.*)$/i.test(title)||/^the requested service is temporarily unavailable/i.test(visible))return result('page_error','服务器返回错误或维护页面',title);
  if(login)return result('login','可连接，返回登录页；未执行登录',title);
  if(!visible&&script)return result('js','可连接，返回 JS 页面；未渲染正文',title);
  if(!visible)return result('empty','未确认可见正文，需复核',title);
  return result('usable','页面可连接（不检查交互和子资源）',title);
 }
 function status(a,n){for(const v of a){if(v.kind==='usable')return '可访问';if(v.kind==='login')return '可连接（登录页）';if(v.kind==='js')return '可连接（JS页面）'}if(!a.length)return '未检测';if(allNetwork(a,n))return '无法连接';const v=a[a.length-1];return ({tls:'证书异常',challenge:'验证码 / 访问受限',page_error:'站点错误页',cancelled:'已取消',empty:'空响应',transport:'失败样本不足',incomplete:'响应不完整'})[v.kind]||(v.kind==='http'?'HTTP '+v.status+'（待确认）':'待确认')}
 function refresh(r){
  const d=r.direct||[],p=r.proxy||[];r.direct=d;r.proxy=p;r.mainland=status(d,3);r.overseas=status(p,2);r.conclusion='待确认';r.reason='尚未取得完整对照证据';r.result='待确认';
  if(r.error){r.reason=r.error;r.mainland='输入无效';return r}
  if(d.some(x=>reachable(x.kind))){r.conclusion='大陆可打开';r.result='否';r.reason='本次大陆线路已返回页面响应';return r}
  if(allNetwork(d,3)&&p.length>=2&&p.slice(-2).every(x=>reachable(x.kind))){r.conclusion='大陆打不开，境外可打开';r.result='是';r.reason='大陆连续3次网络失败，境外连续2次可连接；出口由用户确认，不认定封锁原因';const elapsed=Date.parse(p[0].at)-Date.parse(d[d.length-1].at);if(elapsed>30*60*1000){r.conclusion='需更新大陆检测';r.result='待确认';r.reason='两轮间隔超过30分钟，请重新检测'}}
  else if(allNetwork(d,3)&&allNetwork(p,2)){r.conclusion='两边都无法连接';r.reason='本次两种网络均未连接成功'}
  else if(allNetwork(d,3)&&!p.length){r.reason='大陆连续3次网络失败，等待境外对照'}
  return r;
 }
 function exportCSV(rows,detail){
  const safe=s=>{s=String(s??'');if(/^[\s]*[=+@-]/.test(s))s="'"+s;return '"'+s.replace(/"/g,'""')+'"'};
  const records=[['网址','大陆网络','境外网络','对照结论',...(detail?['原始输入','判断依据','大陆证据','境外证据']:[])]];
  for(const row of rows){const r=refresh({...row});records.push([r.url||r.input,r.mainland,r.overseas,r.conclusion,...(detail?[r.input,r.reason,JSON.stringify(r.direct),JSON.stringify(r.proxy)]:[])])}
  return '\ufeff'+records.map(r=>r.map(safe).join(',')).join('\r\n')+'\r\n';
 }
 return {normalize,parseList,classify,reachable,allNetwork,refresh,status,exportCSV};
}

// Scriptable native Request adapter. Never uses browser fetch for target URLs.
async function nativeProbe(url,requestFactory,classifier,timeout,stopped,network){
 const start=Date.now();const a={kind:'protocol',note:'请求未完成',at:new Date().toISOString(),mode:'ios_system',network,redirects:[]};
 const clean=s=>String(s||'').replace(/(https?|socks5h?):\/\/[^\s/@]+:[^\s/@]+@/gi,'$1://[redacted]@').slice(0,2000);
 let req,redirectLimit=false;
 try{
  if(stopped()){a.kind='cancelled';a.note='检测已取消';return a}
  req=requestFactory(url);req.method='GET';req.timeoutInterval=timeout;req.allowInsecureRequest=false;
  req.headers={'User-Agent':'Mozilla/5.0 (compatible; SiteChecker/2.0; iOS local check)','Accept':'text/html,application/xhtml+xml,text/plain,application/json;q=0.9,*/*;q=0.8','Accept-Language':'zh-CN,zh;q=0.9,en;q=0.8'};
  req.onRedirect=next=>{a.redirects.push(clean(next.url));if(a.redirects.length>=10){redirectLimit=true;return null}return next};
  const body=await req.loadString();const response=req.response||{};a.status=response.statusCode||0;a.final_url=clean(response.url||url);
  if(stopped()){a.kind='cancelled';a.note='检测已取消，未将当前请求计为有效样本';return a}
  if(redirectLimit){a.kind='http';a.error_stage='redirect';a.note='跳转次数达到上限';return a}
  const headers=response.headers||{};let retry='';for(const k of Object.keys(headers)){if(k.toLowerCase()==='retry-after')retry=String(headers[k])}
  if(/^\d+$/.test(retry))a.retry_after_ms=Number(retry)*1000;else if(retry)a.retry_after_ms=Math.max(0,Date.parse(retry)-Date.now())||0;
  if(!a.status){a.kind='protocol';a.note='没有取得 HTTP 状态码';return a}
  if(a.status<200||a.status>=300){a.kind='http';a.error_stage='http';a.note='HTTP '+a.status+'：服务器已响应，目标页面未正常返回';return a}
  const text=String(body??'');a.chars_read=Math.min(text.length,524288);a.truncated=text.length>524288;
  const result=await classifier(response.mimeType||headers['Content-Type']||'',response.url||url,text.slice(0,524288),a.truncated);Object.assign(a,result);
 }catch(e){
  a.detail=clean(e.message||e);const code=String(e.code||'')+' '+a.detail;
  if(stopped()||/(?:^|[^0-9])-999\b/.test(code)){a.kind='cancelled';a.error_stage='cancelled';a.note='检测已取消'}
  else if(/-120[0-6]\b|certificate|证书/i.test(code)){a.kind='tls';a.error_stage='tls';a.note='TLS / 证书异常，需复核'}
  else if(req?.response?.statusCode){a.kind='incomplete';a.status=req.response.statusCode;a.final_url=clean(req.response.url||url);a.error_stage='body';a.note='已收到响应，但未完成读取'}
  else if(/-1003\b|-1006\b|cannot find host|找不到.*服务器|DNS/i.test(code)){a.kind='transport';a.error_stage='dns';a.note='DNS 解析失败'}
  else if(/-1001\b|timed out|超时/i.test(code)){a.kind='transport';a.error_stage='timeout';a.note='请求超时'}
  else if(/-1004\b|-1005\b|-1009\b|connection.*(?:lost|refused)|not connected to.*internet/i.test(code)){a.kind='transport';a.error_stage='connection';a.note='网络连接失败或中断'}
  else{a.kind='protocol';a.error_stage='unknown';a.note='无法可靠分类的请求异常，需复核'}
 }finally{a.elapsed_ms=Date.now()-start}
 return a;
}
async function nativeCheck(url,phase,probe,wait,stopped){
 const out=[];const max=phase==='direct'?3:2,required=phase==='direct'?1:2;let successes=0;
 for(let i=0;i<max&&!stopped();i++){
  const a=await probe(url);out.push(a);const ok=['usable','login','js'].includes(a.kind);successes=ok?successes+1:0;
  if(successes>=required||a.kind==='cancelled')break;
  const retryable=a.kind==='transport'||(a.kind==='http'&&[429,502,503,504].includes(a.status));if(!ok&&!retryable)break;
  if(i<max-1){const delay=Math.max(700*(2**i),a.retry_after_ms||0);if(delay>30000)break;await wait(delay)}
 }return out;
}

// Run in the Scriptable app itself, not a widget or a Siri extension.
async function iosMain(){
 const logic=createCore(),fm=FileManager.local();
 const folder=fm.joinPath(fm.libraryDirectory(),'SiteChecker-v2');if(!fm.fileExists(folder))fm.createDirectory(folder,true);
 const file=fm.joinPath(folder,'session.json'),backup=fm.joinPath(folder,'session.backup.json');
 let session={version:2,rows:[],timeout:12,network:'',control:'',stage:'ready'};
 for(const candidate of [file,backup]){if(fm.fileExists(candidate)){try{const data=JSON.parse(fm.readString(candidate));if(data.version===2&&Array.isArray(data.rows)){session=data;break}}catch(e){console.log('检测记录读取失败，将尝试备份。')}}}
 const save=()=>{const temp=fm.joinPath(folder,'session.tmp.json');fm.writeString(temp,JSON.stringify(session));if(fm.fileExists(file)){if(fm.fileExists(backup))fm.remove(backup);fm.copy(file,backup);fm.remove(file)}fm.move(temp,file)};
 if(session.running){session.running=false;session.stage='interrupted';save()}
 const parser=new WebView();await parser.loadHTML('<!doctype html><meta http-equiv="Content-Security-Policy" content="default-src \'none\'"><title>Local parser</title>');
 await parser.evaluateJavaScript('var SiteCore=('+createCore.toString()+')();');
 const bridge=async(method,args)=>JSON.parse(await parser.evaluateJavaScript('JSON.stringify(SiteCore.'+method+'(...'+JSON.stringify(args)+'))'));
 const classifier=async(mime,url,body,truncated)=>JSON.parse(await parser.evaluateJavaScript('JSON.stringify(SiteCore.classify('+JSON.stringify(mime)+',new URL('+JSON.stringify(url)+').pathname,'+JSON.stringify(body)+','+JSON.stringify(truncated)+'))'));
 async function alert(title,message,actions=['确定']){const a=new Alert();a.title=title;a.message=message;for(const item of actions)a.addAction(item);a.addCancelAction('取消');return await a.presentAlert()}
 const wait=ms=>new Promise(resolve=>Timer.schedule(ms,false,resolve));
 async function loadList(text){
  if(!text||text.length>1024*1024){await alert('输入无效','请提供不超过1MB的 UTF-8 网址列表。');return}
  const rows=await bridge('parseList',[text]);if(!rows.length||rows.length>100){await alert('批次数量','iOS 每批1–100条，建议先用20–50条。');return}
  if(session.rows.length&&await alert('替换当前列表','将清除当前结果，请先导出需要保留的结果。',['替换'])!==0)return;
  session.rows=rows;session.stage='ready';session.running=false;save();await alert('已导入',rows.length+'条网址，下一步请选择“检测大陆网络”。');
 }
 async function showResults(targetOnly=false){
  const table=new UITable();table.showSeparators=true;const rows=session.rows.map(logic.refresh).filter(r=>!targetOnly||r.result==='是');
  if(!rows.length){const r=new UITableRow();r.addText('暂无符合条件的结果');table.addRow(r)}
  for(const item of rows){const row=new UITableRow();row.height=100;row.addText(item.url||item.input,item.mainland+' / '+item.overseas+'\n'+item.conclusion);row.dismissOnSelect=false;row.onSelect=async()=>{await QuickLook.present((item.url||item.input)+'\n'+item.reason+'\n\n'+JSON.stringify({direct:item.direct,proxy:item.proxy},null,2))};table.addRow(row)}
  await table.present(false);
 }
 async function settings(){const a=new Alert();a.title='本轮设置';a.message='网络备注由你填写，不自动验证位置。iOS 超时为网络空闲超时；缓慢持续传输可能超过该时间。';a.addTextField('空闲超时秒数（2–60）',String(session.timeout));a.addTextField('本轮网络备注',session.network||'');a.addTextField('可选：已知能打开的检查网址',session.control||'');a.addAction('保存');a.addCancelAction('取消');if(await a.presentAlert()!==0)return;const timeout=Number(a.textFieldValue(0));if(!Number.isInteger(timeout)||timeout<2||timeout>60){await alert('超时无效','请输入2–60的整数');return}const control=a.textFieldValue(2).trim();if(control){try{await bridge('normalize',[control])}catch(e){await alert('网址无效','请核对连通检查网址');return}}session.timeout=timeout;session.network=a.textFieldValue(1).slice(0,100);session.control=control;save()}
 async function run(phase){
  if(!session.rows.length){await alert('请先导入网址','从剪贴板或 TXT 导入，一行一个网址。');return}
  if(phase==='proxy'&&!session.rows.some(r=>(r.direct||[]).length)){await alert('尚无大陆检测','请先关闭 VPN，检测大陆网络。');return}
  const msg=phase==='direct'?'确认当前使用大陆网络，关闭所有 VPN/代理。重新检测会替换两轮旧结果。':'确认已开启可用的境外全局 VPN/代理，且 Scriptable 的请求包含在代理范围内。大陆已可连接的网址会跳过。';
  if(await alert('确认本轮网络',msg+'\n\n请在检测时保持应用前台、不锁屏。网络位置由你确认。',['开始'])!==0)return;
  let stopped=false;const table=new UITable();table.showSeparators=true;let done=0;let current='准备检测…';let completed=false;
  const targets=[];for(let i=0;i<session.rows.length;i++){const row=session.rows[i];if(phase==='direct'){row.direct=[];row.proxy=[]}else{row.proxy=[]}logic.refresh(row);if(!row.error&&(phase==='direct'||row.result!=='否'))targets.push(i)}
  session.running=true;session.stage=phase;save();
  function paint(){table.removeAllRows();let row=new UITableRow();row.height=90;row.addText((phase==='direct'?'大陆':'境外')+'检测 '+done+'/'+targets.length,current);table.addRow(row);row=new UITableRow();row.height=70;row.addText(completed?'已结束，点击“完成”返回菜单':'停止后续检测','当前请求会在完成或超时后结束；点击“完成”也会停止。');row.dismissOnSelect=false;row.onSelect=()=>{stopped=true;current='正在停止，请等待当前请求结束…';paint()};table.addRow(row);table.reload()}
  paint();const presented=table.present(false).then(()=>{stopped=true});
  const probe=url=>nativeProbe(url,u=>new Request(u),classifier,session.timeout,()=>stopped,session.network||'');
  try{
   if(session.control){const u=await bridge('normalize',[session.control]);const controls=await nativeCheck(u,'proxy',probe,wait,()=>stopped);if(!controls.some(a=>a.status>0))throw Error('连通检查未取得 HTTP 响应，请核对网络或检查网址。')}
   for(const i of targets){if(stopped)break;current=session.rows[i].url;paint();const evidence=await nativeCheck(current,phase,probe,wait,()=>stopped);session.rows[i][phase==='direct'?'direct':'proxy']=evidence;logic.refresh(session.rows[i]);done++;save();paint()}
   session.stage=stopped?'cancelled':phase+'_done';current=stopped?'已停止，未完成行保留待确认。':'本轮完成。点击“完成”后可查看、筛选或导出结果。';
  }catch(e){session.stage='failed';current='本轮停止：'+String(e.message||e)}
  finally{session.running=false;completed=true;save();paint();await presented}
 }
 if(session.stage==='interrupted')await alert('上轮检测中断','已保留完成的结果。未完成网址保持待确认，可重新检测。');
 while(true){
  const a=new Alert();a.title='站点访问对照 · iOS v2';a.message='本机独立检测 · '+session.rows.length+'条\n网络：'+(session.network||'未备注')+'\n状态：'+session.stage+'\n先测大陆，再切换境外出口运行第二轮。';
  for(const label of ['从剪贴板导入网址','导入 TXT 文件','检测大陆网络','检测境外网络','查看全部结果','只看大陆打不开、境外可打开','导出结果 CSV','导出详细依据','超时 / 网络备注 / 连通检查'])a.addAction(label);a.addCancelAction('退出');
  const action=await a.presentSheet();if(action<0)break;
  try{switch(action){case 0:await loadList(Pasteboard.pasteString());break;case 1:{const paths=await DocumentPicker.open(['public.plain-text']);if(paths.length)await loadList(fm.readString(paths[0]));break}case 2:await run('direct');break;case 3:await run('proxy');break;case 4:await showResults();break;case 5:await showResults(true);break;case 6:case 7:{const choice=await alert('导出范围','导出全部结果或仅导出目标网址。',['全部结果','仅目标网址']);if(choice<0)break;const rows=session.rows.map(logic.refresh).filter(r=>choice===0||r.result==='是');await DocumentPicker.exportString(logic.exportCSV(rows,action===7),'site-results'+(action===7?'-detail':'')+'.csv');break}case 8:await settings();break}}catch(e){await alert('操作未完成',String(e.message||e))}
 }
}
await iosMain();
Script.complete();
