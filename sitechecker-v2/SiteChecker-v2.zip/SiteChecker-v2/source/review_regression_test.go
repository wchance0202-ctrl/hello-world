package main

import (
	"context"
	"crypto/tls"
	"net/http"
	"net/http/httptest"
	"testing"
	"time"
)

func TestReviewTLSProtocolMismatchIsNotNetworkFailure(t *testing.T) {
	s := httptest.NewUnstartedServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) { w.Write([]byte("Hello")) }))
	s.TLS = &tls.Config{MinVersion: tls.VersionTLS10, MaxVersion: tls.VersionTLS11}
	s.StartTLS()
	defer s.Close()
	c, e := NewClient("", time.Second)
	if e != nil {
		t.Fatal(e)
	}
	defer c.CloseIdleConnections()
	a := Probe(context.Background(), c, s.URL)
	if a.Kind != "tls" {
		t.Fatalf("TLS negotiation became network evidence: %+v", a)
	}
}
func TestReviewLiteralMarkdownPunctuationPreserved(t *testing.T) {
	for _, u := range []string{"https://example.com/a](b)", "example.com/a](b)"} {
		r := ParseList(u)
		want := u
		if u[0] != 'h' {
			want = "https://" + u
		}
		if len(r) != 1 || r[0].URL != want {
			t.Fatalf("%s -> %+v", u, r)
		}
	}
}
