const fs=require('node:fs');const assert=require('node:assert/strict');const {chromium}=require('playwright');
(async()=>{const browser=await chromium.launch({executablePath:process.env.CHROMIUM_PATH||'/usr/bin/chromium',args:['--no-sandbox']});try{const page=await browser.newPage();await page.setContent('<meta http-equiv="Content-Security-Policy" content="default-src \'none\'">');await page.evaluate('(function(){'+fs.readFileSync(process.env.CORE_FILE||'mobile/core.js','utf8')+';globalThis.core=createCore();})()');
const results=await page.evaluate(()=>{
 const rows=core.parseList('example.com/redirect?next=https://other.example/path\nhttps://example.org\nhttps://example.org');
 const short=core.classify('text/html','/', '<html><body>Hi</body></html>',false);
 const js=core.classify('text/html','/', '<html><body><script>'+ 'x'.repeat(524288),true);
 const error=core.classify('text/html','/', '<html><title>Service Unavailable</title><body>Try later</body></html>',false);
 const login=core.classify('text/html','/login','<html><input type=password></html>',false);
 const cancelled=core.refresh({url:'https://a.example',direct:[{kind:'transport'},{kind:'cancelled'}],proxy:[{kind:'usable'},{kind:'usable'}]});
 const target=core.refresh({url:'https://a.example',direct:[{kind:'transport'},{kind:'transport'},{kind:'transport'}],proxy:[{kind:'usable',status:200,final_url:'https://final.example'},{kind:'login'}]});
 return {punctuation:core.parseList('https://example.com/a](b)')[0].url,rows,short,js,error,login,cancelled,target,csv:core.exportCSV([target],true)};
});
assert.equal(results.punctuation,'https://example.com/a](b)');assert.equal(results.rows[0].url,'https://example.com/redirect?next=https://other.example/path');assert.equal(results.rows.length,3);assert.equal(results.short.kind,'usable');assert.equal(results.js.kind,'js');assert.equal(results.error.kind,'page_error');assert.equal(results.login.kind,'login');assert.equal(results.cancelled.conclusion,'待确认');assert.equal(results.target.conclusion,'大陆打不开，境外可打开');assert.ok(results.csv.includes('https://final.example'));assert.ok(results.csv.startsWith('\ufeff'));console.log('Mobile core: parsing, classification, cancellation, comparison, export PASS');
}finally{await browser.close()}})().catch(e=>{console.error(e);process.exitCode=1});
