# Validation

Go: `go test -race ./...` and `go vet ./...`.

Browser/mobile core tests require Node, Playwright and Chromium. Set CHROMIUM_PATH if needed.

Build the host binary with `go build -mod=vendor -buildvcs=false -o sitechecker .`.
Then run `node tests/browser-smoke.cjs`. Alternatively set SITECHECKER_BINARY to its absolute path.
The browser test uses local fixture servers only and writes preview-test.png (SITECHECKER_SCREENSHOT overrides it).
Run `node tests/mobile.test.cjs`, `node tests/native-adapter.test.cjs`, `node tests/poll-race.test.cjs`.
The native-adapter test simulates Scriptable APIs; it does not test an actual iPhone.
The iOS script is assembled by concatenating mobile/core.js, mobile/native.js and mobile/ios-main.js.
