const fs=require('node:fs'),vm=require('node:vm'),assert=require('node:assert/strict');
const box={Date,String,JSON,Math};vm.createContext(box);vm.runInContext(fs.readFileSync('mobile/native.js','utf8'),box);
(async()=>{
 let seen;
 const factory=url=>(seen={url,response:{statusCode:200,url,headers:{'Content-Type':'text/html'}},loadString:async()=>'<body>Hello</body>'});
 let a=await box.nativeProbe('https://example.com',factory,async()=>({kind:'usable',note:'ok'}),12,()=>false,'test');assert.equal(a.kind,'usable');assert.equal(seen.timeoutInterval,12);assert.equal(seen.allowInsecureRequest,false);assert.equal(a.mode,'ios_system');
 a=await box.nativeProbe('https://example.com',()=>({loadString:async()=>{throw Error('NSURLErrorDomain Code=-1003')}}),async()=>{},12,()=>false,'');assert.equal(a.kind,'transport');assert.equal(a.error_stage,'dns');
 a=await box.nativeProbe('https://example.com',()=>({loadString:async()=>{throw Error('NSURLErrorDomain Code=-1202 certificate')}}),async()=>{},12,()=>false,'');assert.equal(a.kind,'tls');
 a=await box.nativeProbe('https://example.com',()=>({loadString:async()=>{throw Error('Something unexpected')}}),async()=>{},12,()=>false,'');assert.equal(a.kind,'protocol');
 let calls=0;const evidence=await box.nativeCheck('https://example.com','direct',async()=>{calls++;return {kind:'http',status:403}},async()=>{},()=>false);assert.equal(calls,1);assert.equal(evidence.length,1);
 calls=0;await box.nativeCheck('https://example.com','proxy',async()=>{calls++;return {kind:'login'}},async()=>{},()=>false);assert.equal(calls,2);
 console.log('Native adapter contract: verified TLS, error categories, retry rules PASS (simulated Scriptable API)');
})().catch(e=>{console.error(e);process.exitCode=1});
