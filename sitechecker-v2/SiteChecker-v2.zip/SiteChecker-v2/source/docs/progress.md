# Release status

See progress-v2.md and the bundled 验证说明.txt for the verified scope.
