# SiteChecker v2

Current design: superpowers/specs/2026-10-29-v2-design.md.
The original v1 design is superseded by mainland / overseas / comparison columns and native mobile runtime solutions.
