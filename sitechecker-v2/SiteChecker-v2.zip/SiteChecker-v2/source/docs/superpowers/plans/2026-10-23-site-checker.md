# Site Checker Implementation Plan

> Execute inline in this isolated scratch workspace; user requested direct implementation.

**Goal:** Deliver a no-install Windows tool for batch direct/proxy comparison.
**Architecture:** Go standard library, embedded local browser UI, two-phase checks.
**Tech Stack:** Go, HTML/CSS/JS; no runtime dependencies.
**Spec:** ../../design.md

## Global Constraints
- Windows 10/11 x64; no Python or external accounts.
- Yes/no only when supported; unknown stays 待确认.
- Preserve input order and duplicates; no secret proxy credentials in exports.

## Review Focus
- 200 challenge / login / JS shell pages must not become accessibility successes.
- Certificate and HTTP failures must not become proxy-required conclusions.
- System proxy and TUN may contaminate baseline: explicit user confirmation.
- Cancellation and overlapping jobs must not corrupt results.
- Spreadsheet formulas, malformed inputs and CSV escaping.

### Task 1: Core detection and export
- [x] Write behavior tests for normalization, classify decision matrix, retries, redirects, HTTP/challenge responses, CSV safety.
- [x] Run tests and verify missing implementation fails.
- [x] Implement engine, preserve evidence and robust retry rules.
- [x] Run complete core test suite.

### Task 2: Local UI and Windows package
- [x] Add API tests for route authentication, phase gating, job conflicts, cancellation, export order.
- [x] Implement local server, embedded UI, system proxy detection and browser opening.
- [x] Exercise local workflow with deterministic fixtures, inspect browser screenshot where supported.
- [x] Run race tests and vet; cross-build Windows x64; verify PE architecture.
- [x] Package binary, README, sample list and full source; save final ZIP.

## Verification
17 top-level tests plus decision subcases pass with race detector; go vet passes. HTTPS CONNECT and full two-phase proxy flow covered. Linux compiled-binary smoke covers startup, HTML delivery, scan, duplicates, invalid input, CSV download. Windows x64 PE cross-build verified; native Windows execution and mainland network not available. Browser visual QA could not run because the browser runtime download failed; HTML element references and JS syntax checked.

## Review
Independent review found three important cases. Fixed cancellation during body reads and root login forms with RED→GREEN tests. Removed unsupported CSV import; TXT import and Excel-column paste remain. No deferred findings.
