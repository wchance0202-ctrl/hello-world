package main

import (
	"context"
	"errors"
	"fmt"
	"net"
	"net/http"
	"net/url"
	"os"
	"os/exec"
	"runtime"
	"strconv"
	"strings"
	"time"
)

func proxyURL(raw, kind string) (*url.URL, error) {
	if !strings.Contains(raw, "://") {
		if kind == "socks" {
			raw = "socks5://" + raw
		} else {
			raw = "http://" + raw
		}
	}
	p, e := url.Parse(raw)
	if e != nil || p == nil || p.Hostname() == "" || strings.ContainsAny(p.Host, " \r\n\t") || (p.Scheme != "http" && p.Scheme != "https" && p.Scheme != "socks5" && p.Scheme != "socks5h") || p.RawQuery != "" || p.Fragment != "" || (p.Path != "" && p.Path != "/") {
		return nil, errors.New("代理地址无效，请填写 HTTP / HTTPS / SOCKS5 地址和端口")
	}
	if port := p.Port(); port != "" {
		n, e := strconv.Atoi(port)
		if e != nil || n < 1 || n > 65535 {
			return nil, errors.New("代理端口无效")
		}
	}
	return p, nil
}
func ProxyResolver(setting string) (func(*http.Request) (*url.URL, error), error) {
	values := map[string]*url.URL{}
	// '=' in a password is not a Windows protocol map.
	if !strings.Contains(setting, "://") && strings.Contains(setting, "=") || strings.HasPrefix(setting, "http=") || strings.HasPrefix(setting, "https=") || strings.HasPrefix(setting, "socks=") {
		for _, part := range strings.Split(setting, ";") {
			kv := strings.SplitN(strings.TrimSpace(part), "=", 2)
			if len(kv) != 2 {
				continue
			}
			key := strings.ToLower(strings.TrimSpace(kv[0]))
			if key != "http" && key != "https" && key != "socks" {
				continue
			}
			p, e := proxyURL(strings.TrimSpace(kv[1]), key)
			if e != nil {
				return nil, e
			}
			values[key] = p
		}
		if len(values) == 0 {
			return nil, errors.New("未找到 HTTP / HTTPS / SOCKS 代理配置")
		}
	} else {
		p, e := proxyURL(strings.TrimSpace(setting), "")
		if e != nil {
			return nil, e
		}
		values["all"] = p
	}
	return func(r *http.Request) (*url.URL, error) {
		for _, key := range []string{r.URL.Scheme, "all", "socks"} {
			if p := values[key]; p != nil {
				return p, nil
			}
		}
		return nil, fmt.Errorf("系统未配置 %s 代理；请填写可同时处理 HTTP/HTTPS 的代理地址", r.URL.Scheme)
	}, nil
}
func ProxyFromSetting(s string) string {
	f, e := ProxyResolver(s)
	if e != nil {
		return ""
	}
	for _, scheme := range []string{"https", "http"} {
		r, _ := http.NewRequest("GET", scheme+"://example.com", nil)
		if p, e := f(r); e == nil {
			return p.String()
		}
	}
	return ""
}
func ParseMacProxy(s string) string {
	m := map[string]string{}
	for _, line := range strings.Split(s, "\n") {
		kv := strings.SplitN(line, ":", 2)
		if len(kv) == 2 {
			m[strings.TrimSpace(kv[0])] = strings.TrimSpace(kv[1])
		}
	}
	out := []string{}
	for _, v := range []struct{ key, name string }{{"HTTP", "http"}, {"HTTPS", "https"}, {"SOCKS", "socks"}} {
		if m[v.key+"Enable"] == "1" && m[v.key+"Proxy"] != "" && m[v.key+"Port"] != "" {
			out = append(out, v.name+"="+net.JoinHostPort(m[v.key+"Proxy"], m[v.key+"Port"]))
		}
	}
	return strings.Join(out, ";")
}
func DetectProxy() (string, error) {
	ctx, cancel := context.WithTimeout(context.Background(), 3*time.Second)
	defer cancel()
	if runtime.GOOS == "windows" {
		path := `HKCU\Software\Microsoft\Windows\CurrentVersion\Internet Settings`
		enabled, e := exec.CommandContext(ctx, "reg.exe", "query", path, "/v", "ProxyEnable").Output()
		if e == nil && strings.Contains(strings.ToLower(string(enabled)), "0x1") {
			if b, e := exec.CommandContext(ctx, "reg.exe", "query", path, "/v", "ProxyServer").Output(); e == nil {
				for _, line := range strings.Split(string(b), "\n") {
					if i := strings.Index(line, "REG_SZ"); i >= 0 {
						s := strings.TrimSpace(line[i+len("REG_SZ"):])
						if _, e := ProxyResolver(s); e == nil {
							return s, nil
						}
					}
				}
			}
		}
	} else if runtime.GOOS == "darwin" {
		if b, e := exec.CommandContext(ctx, "/usr/sbin/scutil", "--proxy").Output(); e == nil {
			if s := ParseMacProxy(string(b)); s != "" {
				return s, nil
			}
		}
	}
	env := func(keys ...string) string {
		for _, key := range keys {
			if s := os.Getenv(key); s != "" {
				return s
			}
		}
		return ""
	}
	if all := env("ALL_PROXY", "all_proxy"); all != "" {
		if _, e := proxyURL(all, ""); e == nil {
			return all, nil
		}
	}
	entries := []string{}
	for _, v := range []struct {
		scheme string
		keys   []string
	}{{"http", []string{"HTTP_PROXY", "http_proxy"}}, {"https", []string{"HTTPS_PROXY", "https_proxy"}}} {
		if s := env(v.keys...); s != "" {
			if _, e := proxyURL(s, ""); e == nil {
				entries = append(entries, v.scheme+"="+s)
			}
		}
	}
	if len(entries) > 0 {
		return strings.Join(entries, ";"), nil
	}
	return "", errors.New("未找到静态系统代理。请开启系统代理，或手动填写 HTTP/SOCKS5 地址；全局 VPN/TUN 请选择对应模式。PAC 暂不自动执行。")
}
func ProxyPreflight(ctx context.Context, client *http.Client, urls []string) error {
	tr, ok := client.Transport.(*http.Transport)
	if !ok || tr.Proxy == nil {
		return nil
	}
	seen := map[string]bool{}
	for _, raw := range urls {
		r, e := http.NewRequest("GET", raw, nil)
		if e != nil {
			continue
		}
		p, e := tr.Proxy(r)
		if e != nil {
			return e
		}
		if p == nil {
			return errors.New("境外模式没有显式代理")
		}
		port := p.Port()
		if port == "" {
			port = "80"
			if p.Scheme == "https" {
				port = "443"
			}
			if strings.HasPrefix(p.Scheme, "socks") {
				port = "1080"
			}
		}
		addr := net.JoinHostPort(p.Hostname(), port)
		if seen[addr] {
			continue
		}
		seen[addr] = true
		c, e := (&net.Dialer{Timeout: 3 * time.Second}).DialContext(ctx, "tcp", addr)
		if e != nil {
			return fmt.Errorf("无法连接代理 %s，请先启动代理并核对端口", addr)
		}
		c.Close()
	}
	return nil
}
