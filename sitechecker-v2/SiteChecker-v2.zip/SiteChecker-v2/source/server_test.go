package main

import (
	"bytes"
	"encoding/json"
	"io"
	"net"
	"net/http"
	"net/http/httptest"
	"strings"
	"sync/atomic"
	"testing"
	"time"
)

func requestAPI(t *testing.T, s *httptest.Server, method, path, body string) (int, []byte) {
	t.Helper()
	req, err := http.NewRequest(method, s.URL+path, strings.NewReader(body))
	if err != nil {
		t.Fatal(err)
	}
	req.Header.Set("Content-Type", "application/json")
	resp, err := s.Client().Do(req)
	if err != nil {
		t.Fatal(err)
	}
	defer resp.Body.Close()
	b, _ := io.ReadAll(resp.Body)
	return resp.StatusCode, b
}
func TestAPICapabilityAndConfirmationGates(t *testing.T) {
	app := NewApp("test-secret")
	s := httptest.NewServer(app.Handler())
	defer s.Close()
	code, _ := requestAPI(t, s, "GET", "/wrong/api/state", "")
	if code != 404 {
		t.Fatal(code)
	}
	code, _ = requestAPI(t, s, "POST", "/test-secret/api/start", `{"phase":"direct","text":"example.com"}`)
	if code != 400 {
		t.Fatal("baseline without confirmation accepted", code)
	}
	code, _ = requestAPI(t, s, "POST", "/test-secret/api/start", `{"phase":"proxy","confirm":true,"mode":"tun"}`)
	if code != 400 {
		t.Fatal("comparison without baseline", code)
	}
	req, _ := http.NewRequest("POST", s.URL+"/test-secret/api/start", bytes.NewBufferString(`{}`))
	req.Header.Set("Origin", "https://evil.example")
	resp, e := s.Client().Do(req)
	if e != nil {
		t.Fatal(e)
	}
	resp.Body.Close()
	if resp.StatusCode != 403 {
		t.Fatal("foreign origin accepted", resp.StatusCode)
	}
}
func TestAPIFullDirectFlowAndExport(t *testing.T) {
	target := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "text/plain")
		io.WriteString(w, strings.Repeat("Market content. ", 20))
	}))
	defer target.Close()
	app := NewApp("t")
	s := httptest.NewServer(app.Handler())
	defer s.Close()
	body, _ := json.Marshal(map[string]any{"phase": "direct", "confirm": true, "text": target.URL + "\n" + target.URL, "timeout": 2})
	code, b := requestAPI(t, s, "POST", "/t/api/start", string(body))
	if code != 200 {
		t.Fatal(code, string(b))
	}
	deadline := time.Now().Add(3 * time.Second)
	var st State
	for time.Now().Before(deadline) {
		_, b = requestAPI(t, s, "GET", "/t/api/state", "")
		if e := json.Unmarshal(b, &st); e != nil {
			t.Fatal(e)
		}
		if !st.Running {
			break
		}
		time.Sleep(10 * time.Millisecond)
	}
	if st.Running || len(st.Rows) != 2 || st.Rows[0].Result != "否" || st.Done != 2 || st.Stage != "direct_done" {
		t.Fatalf("bad state %+v", st)
	}
	code, b = requestAPI(t, s, "GET", "/t/api/export", "")
	if code != 200 || bytes.Count(b, []byte(target.URL)) != 2 {
		t.Fatal(code, string(b))
	}
}
func TestAPIBusyAndCancel(t *testing.T) {
	entered := make(chan struct{}, 8)
	target := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) { entered <- struct{}{}; <-r.Context().Done() }))
	defer target.Close()
	app := NewApp("t")
	s := httptest.NewServer(app.Handler())
	defer s.Close()
	body, _ := json.Marshal(map[string]any{"phase": "direct", "confirm": true, "text": target.URL, "timeout": 2})
	code, b := requestAPI(t, s, "POST", "/t/api/start", string(body))
	if code != 200 {
		t.Fatal(code, string(b))
	}
	<-entered
	code, _ = requestAPI(t, s, "POST", "/t/api/start", string(body))
	if code != 409 {
		t.Fatal("allowed overlapping scan", code)
	}
	code, _ = requestAPI(t, s, "POST", "/t/api/cancel", `{}`)
	if code != 200 {
		t.Fatal(code)
	}
	for i := 0; i < 100; i++ {
		_, b = requestAPI(t, s, "GET", "/t/api/state", "")
		var st State
		json.Unmarshal(b, &st)
		if !st.Running {
			if st.Stage != "cancelled" {
				t.Fatal(st.Stage)
			}
			return
		}
		time.Sleep(10 * time.Millisecond)
	}
	t.Fatal("cancel did not finish")
}
func TestProxySettingsParser(t *testing.T) {
	for input, want := range map[string]string{"127.0.0.1:7890": "http://127.0.0.1:7890", "http=127.0.0.1:1;https=127.0.0.1:2": "http://127.0.0.1:2", "socks=127.0.0.1:1080": "socks5://127.0.0.1:1080"} {
		if got := ProxyFromSetting(input); got != want {
			t.Errorf("%s -> %s, want %s", input, got, want)
		}
	}
}

func TestAPITwoPhaseProxyComparison(t *testing.T) {
	listener, err := net.Listen("tcp", "127.0.0.1:0")
	if err != nil {
		t.Fatal(err)
	}
	deadURL := "http://" + listener.Addr().String()
	listener.Close()
	var proxyCalls atomic.Int32
	proxy := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		proxyCalls.Add(1)
		w.Header().Set("Content-Type", "text/plain")
		io.WriteString(w, strings.Repeat("Proxy control content. ", 30))
	}))
	defer proxy.Close()
	app := NewApp("t")
	s := httptest.NewServer(app.Handler())
	defer s.Close()
	wait := func() State {
		deadline := time.Now().Add(4 * time.Second)
		for time.Now().Before(deadline) {
			st := app.snapshot()
			if !st.Running {
				return st
			}
			time.Sleep(10 * time.Millisecond)
		}
		t.Fatal("job timeout")
		return State{}
	}
	direct, _ := json.Marshal(StartRequest{Phase: "direct", Text: deadURL, Confirm: true, Timeout: 2})
	code, b := requestAPI(t, s, "POST", "/t/api/start", string(direct))
	if code != 200 {
		t.Fatal(code, string(b))
	}
	st := wait()
	if len(st.Rows[0].Direct) != 3 || st.Rows[0].Result != "待确认" {
		t.Fatal(st)
	}
	q, _ := json.Marshal(StartRequest{Phase: "proxy", Confirm: true, Mode: "manual", Proxy: proxy.URL, Timeout: 2})
	code, b = requestAPI(t, s, "POST", "/t/api/start", string(q))
	if code != 200 {
		t.Fatal(code, string(b))
	}
	st = wait()
	if st.Rows[0].Result != "是" || proxyCalls.Load() != 2 {
		t.Fatalf("bad proxy comparison %+v, calls %d", st, proxyCalls.Load())
	}
}
