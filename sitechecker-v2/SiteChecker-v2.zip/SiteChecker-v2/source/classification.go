package main

import (
	"bytes"
	"io"
	"regexp"
	"strings"

	"golang.org/x/net/html"
)

var loginPathRE = regexp.MustCompile(`(?i)/(?:login|signin|sign-in)(?:/|$)`)
var challengeTitleRE = regexp.MustCompile(`(?i)^(?:just a moment[.!… ]*|attention required.*|access denied[.! ]*|verify you are human.*|security verification.*|robot check.*|安全验证.*|人机验证.*|访问受限.*|访问验证.*|访问被拒绝.*)$`)
var errorTitleRE = regexp.MustCompile(`(?i)^(?:(?:error\s*)?(?:403|404|500|502|503|504)\b.*|service unavailable.*|temporarily unavailable.*|internal server error.*|bad gateway.*|gateway timeout.*|page not found.*|服务不可用.*|系统维护.*|网站维护.*)$`)

func Classify(ctype, path string, b []byte, truncated bool) (kind, note, title string) {
	if len(bytes.TrimSpace(b)) == 0 {
		return "empty", "空响应，需复核", ""
	}
	lower := strings.ToLower(string(b))
	isHTML := strings.Contains(strings.ToLower(ctype), "html") || strings.Contains(lower, "<html") || strings.Contains(lower, "<body") || strings.Contains(lower, "<!doctype html")
	if !isHTML {
		return "usable", "已获得响应内容（仅检查可连接性）", ""
	}
	z := html.NewTokenizer(bytes.NewReader(b))
	var text, titleText strings.Builder
	hidden := 0
	inTitle := false
	script, login, challenge := false, false, false
	for {
		tt := z.Next()
		if tt == html.ErrorToken {
			if z.Err() == io.EOF {
				break
			}
			return "empty", "页面解析不完整，需复核", ""
		}
		switch tt {
		case html.StartTagToken, html.SelfClosingTagToken:
			token := z.Token()
			tag := token.Data
			if tag == "title" {
				inTitle = true
			}
			if tag == "script" {
				script = true
			}
			if tag == "head" || tag == "script" || tag == "style" || tag == "noscript" {
				hidden++
			}
			for _, attr := range token.Attr {
				v := strings.ToLower(attr.Val)
				if tag == "input" && attr.Key == "type" && v == "password" {
					login = true
				}
				if (attr.Key == "src" || attr.Key == "id" || attr.Key == "class") && (strings.Contains(v, "/cdn-cgi/challenge-platform/") || strings.HasPrefix(v, "cf-chl-")) {
					challenge = true
				}
			}
		case html.EndTagToken:
			tag := z.Token().Data
			if tag == "title" {
				inTitle = false
			}
			if (tag == "head" || tag == "script" || tag == "style" || tag == "noscript") && hidden > 0 {
				hidden--
			}
		case html.TextToken:
			s := string(z.Text())
			if inTitle {
				titleText.WriteString(s)
			}
			if hidden == 0 && !inTitle {
				text.WriteString(s)
				text.WriteByte(' ')
			}
		}
	}
	title = strings.Join(strings.Fields(titleText.String()), " ")
	visible := strings.Join(strings.Fields(text.String()), " ")
	v := strings.ToLower(visible)
	if challenge || challengeTitleRE.MatchString(title) || strings.HasPrefix(v, "checking your browser before accessing") || strings.HasPrefix(v, "please enable javascript and cookies to continue") || strings.HasPrefix(v, "the requested url was rejected") || strings.HasPrefix(v, "网站已被拦截") || strings.HasPrefix(v, "该网站暂时无法访问") {
		return "challenge", "服务器返回验证 / 拦截页面，需人工确认", title
	}
	if errorTitleRE.MatchString(title) || strings.HasPrefix(v, "the requested service is temporarily unavailable") {
		return "page_error", "服务器返回错误或维护页面", title
	}
	if login || loginPathRE.MatchString(path) {
		return "login", "可连接，返回登录页面；未执行登录", title
	}
	if visible == "" && script {
		return "js", "可连接，返回 JavaScript 页面；未渲染正文", title
	}
	if visible == "" {
		if truncated {
			return "empty", "响应截断，未确认页面内容", title
		}
		return "empty", "未检测到可见正文，需复核", title
	}
	return "usable", "页面可连接（不检查登录、交互或子资源）", title
}
