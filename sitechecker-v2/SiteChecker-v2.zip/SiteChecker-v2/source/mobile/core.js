// Shared pure logic. URL and DOMParser are evaluated only inside an inert WebView.
function createCore(){
 const reachable=k=>['usable','login','js'].includes(k);
 const allNetwork=(a,n)=>a.length>=n&&a.every(x=>x.kind==='transport');
 function normalize(raw){
  let s=String(raw).trim().replace(/^\ufeff/,'');
  if(!/^[a-z][a-z0-9+.-]*:\/\//i.test(s)){
   if(!/^(localhost|[a-z0-9\u3400-\u9fff][a-z0-9.\-\u3400-\u9fff]*\.[a-z\u3400-\u9fff]{2,}|[0-9]+(?:\.[0-9]+){3}|\[[0-9a-f:]+\])(?::[0-9]{1,5})?(?:[/\?#][^\s]*)?$/i.test(s))throw Error('请输入完整网址或有效域名');
   s='https://'+s;
  }
  const u=new URL(s);if(!['http:','https:'].includes(u.protocol)||!u.hostname||u.username||u.password||/\s/.test(u.host)||u.port==='0')throw Error('网址无效，仅支持无账号密码的 HTTP/HTTPS');
  return u.href;
 }
 function parseList(text){
  const rows=[];for(const raw of text.replace(/\r\n/g,'\n').split('\n')){
   const line=raw.trim().replace(/^\ufeff/,'');if(!line)continue;let candidates=[line],extracted=false;
   try{normalize(line)}catch(e){if(line.includes('](')||(!/^[a-z][a-z0-9+.-]*:\/\//i.test(line)&&/[ \t]/.test(line))){const found=line.match(/https?:\/\/[^\s<>"`|]+/gi);if(found){candidates=found;extracted=true}}}
   for(let candidate of candidates){if(extracted&&line.includes(']('))candidate=candidate.replace(/\)$/,'');const r={input:line,url:'',direct:[],proxy:[],recheck:[]};try{r.url=normalize(candidate)}catch(e){r.error=String(e.message||e)}rows.push(refresh(r))}
  }return rows;
 }
 function classify(ctype,path,body,truncated){
  const result=(kind,note,title='')=>({kind,note:note+(truncated?'；仅分析响应前部':''),title,truncated});
  if(!body.trim())return result('empty','空响应，需复核');
  if(!/html/i.test(ctype)&&!/<(?:html|body|!doctype html)\b/i.test(body))return result('usable','已获得响应内容');
  // Detached parsed DOM. Never attach target HTML or run its scripts.
  const d=new DOMParser().parseFromString(body,'text/html');const title=(d.title||'').replace(/\s+/g,' ').trim();
  const script=!!d.querySelector('script');const login=!!d.querySelector('input[type="password" i]')||/\/(?:login|signin|sign-in)(?:\/|$)/i.test(path);
  const challenge=Array.from(d.querySelectorAll('[src],[id],[class]')).some(el=>['src','id','class'].some(k=>{const s=(el.getAttribute(k)||'').toLowerCase();return s.includes('/cdn-cgi/challenge-platform/')||s.startsWith('cf-chl-')}));
  d.querySelectorAll('script,style,head,noscript,template').forEach(n=>n.remove());const visible=(d.body?.textContent||'').replace(/\s+/g,' ').trim();
  if(challenge||/^(?:just a moment[.!… ]*|attention required.*|access denied[.! ]*|verify you are human.*|security verification.*|robot check.*|安全验证.*|人机验证.*|访问受限.*|访问验证.*|访问被拒绝.*)$/i.test(title)||/^(?:checking your browser before accessing|please enable javascript and cookies to continue|the requested url was rejected|网站已被拦截|该网站暂时无法访问)/i.test(visible))return result('challenge','服务器返回验证 / 拦截页面，需人工确认',title);
  if(/^(?:(?:error\s*)?(?:403|404|500|502|503|504)\b.*|service unavailable.*|temporarily unavailable.*|internal server error.*|bad gateway.*|gateway timeout.*|page not found.*|服务不可用.*|系统维护.*|网站维护.*)$/i.test(title)||/^the requested service is temporarily unavailable/i.test(visible))return result('page_error','服务器返回错误或维护页面',title);
  if(login)return result('login','可连接，返回登录页；未执行登录',title);
  if(!visible&&script)return result('js','可连接，返回 JS 页面；未渲染正文',title);
  if(!visible)return result('empty','未确认可见正文，需复核',title);
  return result('usable','页面可连接（不检查交互和子资源）',title);
 }
 function status(a,n){for(const v of a){if(v.kind==='usable')return '可访问';if(v.kind==='login')return '可连接（登录页）';if(v.kind==='js')return '可连接（JS页面）'}if(!a.length)return '未检测';if(allNetwork(a,n))return '无法连接';const v=a[a.length-1];return ({tls:'证书异常',challenge:'验证码 / 访问受限',page_error:'站点错误页',cancelled:'已取消',empty:'空响应',transport:'失败样本不足',incomplete:'响应不完整'})[v.kind]||(v.kind==='http'?'HTTP '+v.status+'（待确认）':'待确认')}
 function refresh(r){
  const d=r.direct||[],p=r.proxy||[];r.direct=d;r.proxy=p;r.mainland=status(d,3);r.overseas=status(p,2);r.conclusion='待确认';r.reason='尚未取得完整对照证据';r.result='待确认';
  if(r.error){r.reason=r.error;r.mainland='输入无效';return r}
  if(d.some(x=>reachable(x.kind))){r.conclusion='大陆可打开';r.result='否';r.reason='本次大陆线路已返回页面响应';return r}
  if(allNetwork(d,3)&&p.length>=2&&p.slice(-2).every(x=>reachable(x.kind))){r.conclusion='大陆打不开，境外可打开';r.result='是';r.reason='大陆连续3次网络失败，境外连续2次可连接；出口由用户确认，不认定封锁原因';const elapsed=Date.parse(p[0].at)-Date.parse(d[d.length-1].at);if(elapsed>30*60*1000){r.conclusion='需更新大陆检测';r.result='待确认';r.reason='两轮间隔超过30分钟，请重新检测'}}
  else if(allNetwork(d,3)&&allNetwork(p,2)){r.conclusion='两边都无法连接';r.reason='本次两种网络均未连接成功'}
  else if(allNetwork(d,3)&&!p.length){r.reason='大陆连续3次网络失败，等待境外对照'}
  return r;
 }
 function exportCSV(rows,detail){
  const safe=s=>{s=String(s??'');if(/^[\s]*[=+@-]/.test(s))s="'"+s;return '"'+s.replace(/"/g,'""')+'"'};
  const records=[['网址','大陆网络','境外网络','对照结论',...(detail?['原始输入','判断依据','大陆证据','境外证据']:[])]];
  for(const row of rows){const r=refresh({...row});records.push([r.url||r.input,r.mainland,r.overseas,r.conclusion,...(detail?[r.input,r.reason,JSON.stringify(r.direct),JSON.stringify(r.proxy)]:[])])}
  return '\ufeff'+records.map(r=>r.map(safe).join(',')).join('\r\n')+'\r\n';
 }
 return {normalize,parseList,classify,reachable,allNetwork,refresh,status,exportCSV};
}
