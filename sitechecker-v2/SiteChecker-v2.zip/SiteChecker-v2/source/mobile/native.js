// Scriptable native Request adapter. Never uses browser fetch for target URLs.
async function nativeProbe(url,requestFactory,classifier,timeout,stopped,network){
 const start=Date.now();const a={kind:'protocol',note:'请求未完成',at:new Date().toISOString(),mode:'ios_system',network,redirects:[]};
 const clean=s=>String(s||'').replace(/(https?|socks5h?):\/\/[^\s/@]+:[^\s/@]+@/gi,'$1://[redacted]@').slice(0,2000);
 let req,redirectLimit=false;
 try{
  if(stopped()){a.kind='cancelled';a.note='检测已取消';return a}
  req=requestFactory(url);req.method='GET';req.timeoutInterval=timeout;req.allowInsecureRequest=false;
  req.headers={'User-Agent':'Mozilla/5.0 (compatible; SiteChecker/2.0; iOS local check)','Accept':'text/html,application/xhtml+xml,text/plain,application/json;q=0.9,*/*;q=0.8','Accept-Language':'zh-CN,zh;q=0.9,en;q=0.8'};
  req.onRedirect=next=>{a.redirects.push(clean(next.url));if(a.redirects.length>=10){redirectLimit=true;return null}return next};
  const body=await req.loadString();const response=req.response||{};a.status=response.statusCode||0;a.final_url=clean(response.url||url);
  if(stopped()){a.kind='cancelled';a.note='检测已取消，未将当前请求计为有效样本';return a}
  if(redirectLimit){a.kind='http';a.error_stage='redirect';a.note='跳转次数达到上限';return a}
  const headers=response.headers||{};let retry='';for(const k of Object.keys(headers)){if(k.toLowerCase()==='retry-after')retry=String(headers[k])}
  if(/^\d+$/.test(retry))a.retry_after_ms=Number(retry)*1000;else if(retry)a.retry_after_ms=Math.max(0,Date.parse(retry)-Date.now())||0;
  if(!a.status){a.kind='protocol';a.note='没有取得 HTTP 状态码';return a}
  if(a.status<200||a.status>=300){a.kind='http';a.error_stage='http';a.note='HTTP '+a.status+'：服务器已响应，目标页面未正常返回';return a}
  const text=String(body??'');a.chars_read=Math.min(text.length,524288);a.truncated=text.length>524288;
  const result=await classifier(response.mimeType||headers['Content-Type']||'',response.url||url,text.slice(0,524288),a.truncated);Object.assign(a,result);
 }catch(e){
  a.detail=clean(e.message||e);const code=String(e.code||'')+' '+a.detail;
  if(stopped()||/(?:^|[^0-9])-999\b/.test(code)){a.kind='cancelled';a.error_stage='cancelled';a.note='检测已取消'}
  else if(/-120[0-6]\b|certificate|证书/i.test(code)){a.kind='tls';a.error_stage='tls';a.note='TLS / 证书异常，需复核'}
  else if(req?.response?.statusCode){a.kind='incomplete';a.status=req.response.statusCode;a.final_url=clean(req.response.url||url);a.error_stage='body';a.note='已收到响应，但未完成读取'}
  else if(/-1003\b|-1006\b|cannot find host|找不到.*服务器|DNS/i.test(code)){a.kind='transport';a.error_stage='dns';a.note='DNS 解析失败'}
  else if(/-1001\b|timed out|超时/i.test(code)){a.kind='transport';a.error_stage='timeout';a.note='请求超时'}
  else if(/-1004\b|-1005\b|-1009\b|connection.*(?:lost|refused)|not connected to.*internet/i.test(code)){a.kind='transport';a.error_stage='connection';a.note='网络连接失败或中断'}
  else{a.kind='protocol';a.error_stage='unknown';a.note='无法可靠分类的请求异常，需复核'}
 }finally{a.elapsed_ms=Date.now()-start}
 return a;
}
async function nativeCheck(url,phase,probe,wait,stopped){
 const out=[];const max=phase==='direct'?3:2,required=phase==='direct'?1:2;let successes=0;
 for(let i=0;i<max&&!stopped();i++){
  const a=await probe(url);out.push(a);const ok=['usable','login','js'].includes(a.kind);successes=ok?successes+1:0;
  if(successes>=required||a.kind==='cancelled')break;
  const retryable=a.kind==='transport'||(a.kind==='http'&&[429,502,503,504].includes(a.status));if(!ok&&!retryable)break;
  if(i<max-1){const delay=Math.max(700*(2**i),a.retry_after_ms||0);if(delay>30000)break;await wait(delay)}
 }return out;
}
