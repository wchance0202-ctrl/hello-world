// Run in the Scriptable app itself, not a widget or a Siri extension.
async function iosMain(){
 const logic=createCore(),fm=FileManager.local();
 const folder=fm.joinPath(fm.libraryDirectory(),'SiteChecker-v2');if(!fm.fileExists(folder))fm.createDirectory(folder,true);
 const file=fm.joinPath(folder,'session.json'),backup=fm.joinPath(folder,'session.backup.json');
 let session={version:2,rows:[],timeout:12,network:'',control:'',stage:'ready'};
 for(const candidate of [file,backup]){if(fm.fileExists(candidate)){try{const data=JSON.parse(fm.readString(candidate));if(data.version===2&&Array.isArray(data.rows)){session=data;break}}catch(e){console.log('检测记录读取失败，将尝试备份。')}}}
 const save=()=>{const temp=fm.joinPath(folder,'session.tmp.json');fm.writeString(temp,JSON.stringify(session));if(fm.fileExists(file)){if(fm.fileExists(backup))fm.remove(backup);fm.copy(file,backup);fm.remove(file)}fm.move(temp,file)};
 if(session.running){session.running=false;session.stage='interrupted';save()}
 const parser=new WebView();await parser.loadHTML('<!doctype html><meta http-equiv="Content-Security-Policy" content="default-src \'none\'"><title>Local parser</title>');
 await parser.evaluateJavaScript('var SiteCore=('+createCore.toString()+')();');
 const bridge=async(method,args)=>JSON.parse(await parser.evaluateJavaScript('JSON.stringify(SiteCore.'+method+'(...'+JSON.stringify(args)+'))'));
 const classifier=async(mime,url,body,truncated)=>JSON.parse(await parser.evaluateJavaScript('JSON.stringify(SiteCore.classify('+JSON.stringify(mime)+',new URL('+JSON.stringify(url)+').pathname,'+JSON.stringify(body)+','+JSON.stringify(truncated)+'))'));
 async function alert(title,message,actions=['确定']){const a=new Alert();a.title=title;a.message=message;for(const item of actions)a.addAction(item);a.addCancelAction('取消');return await a.presentAlert()}
 const wait=ms=>new Promise(resolve=>Timer.schedule(ms,false,resolve));
 async function loadList(text){
  if(!text||text.length>1024*1024){await alert('输入无效','请提供不超过1MB的 UTF-8 网址列表。');return}
  const rows=await bridge('parseList',[text]);if(!rows.length||rows.length>100){await alert('批次数量','iOS 每批1–100条，建议先用20–50条。');return}
  if(session.rows.length&&await alert('替换当前列表','将清除当前结果，请先导出需要保留的结果。',['替换'])!==0)return;
  session.rows=rows;session.stage='ready';session.running=false;save();await alert('已导入',rows.length+'条网址，下一步请选择“检测大陆网络”。');
 }
 async function showResults(targetOnly=false){
  const table=new UITable();table.showSeparators=true;const rows=session.rows.map(logic.refresh).filter(r=>!targetOnly||r.result==='是');
  if(!rows.length){const r=new UITableRow();r.addText('暂无符合条件的结果');table.addRow(r)}
  for(const item of rows){const row=new UITableRow();row.height=100;row.addText(item.url||item.input,item.mainland+' / '+item.overseas+'\n'+item.conclusion);row.dismissOnSelect=false;row.onSelect=async()=>{await QuickLook.present((item.url||item.input)+'\n'+item.reason+'\n\n'+JSON.stringify({direct:item.direct,proxy:item.proxy},null,2))};table.addRow(row)}
  await table.present(false);
 }
 async function settings(){const a=new Alert();a.title='本轮设置';a.message='网络备注由你填写，不自动验证位置。iOS 超时为网络空闲超时；缓慢持续传输可能超过该时间。';a.addTextField('空闲超时秒数（2–60）',String(session.timeout));a.addTextField('本轮网络备注',session.network||'');a.addTextField('可选：已知能打开的检查网址',session.control||'');a.addAction('保存');a.addCancelAction('取消');if(await a.presentAlert()!==0)return;const timeout=Number(a.textFieldValue(0));if(!Number.isInteger(timeout)||timeout<2||timeout>60){await alert('超时无效','请输入2–60的整数');return}const control=a.textFieldValue(2).trim();if(control){try{await bridge('normalize',[control])}catch(e){await alert('网址无效','请核对连通检查网址');return}}session.timeout=timeout;session.network=a.textFieldValue(1).slice(0,100);session.control=control;save()}
 async function run(phase){
  if(!session.rows.length){await alert('请先导入网址','从剪贴板或 TXT 导入，一行一个网址。');return}
  if(phase==='proxy'&&!session.rows.some(r=>(r.direct||[]).length)){await alert('尚无大陆检测','请先关闭 VPN，检测大陆网络。');return}
  const msg=phase==='direct'?'确认当前使用大陆网络，关闭所有 VPN/代理。重新检测会替换两轮旧结果。':'确认已开启可用的境外全局 VPN/代理，且 Scriptable 的请求包含在代理范围内。大陆已可连接的网址会跳过。';
  if(await alert('确认本轮网络',msg+'\n\n请在检测时保持应用前台、不锁屏。网络位置由你确认。',['开始'])!==0)return;
  let stopped=false;const table=new UITable();table.showSeparators=true;let done=0;let current='准备检测…';let completed=false;
  const targets=[];for(let i=0;i<session.rows.length;i++){const row=session.rows[i];if(phase==='direct'){row.direct=[];row.proxy=[]}else{row.proxy=[]}logic.refresh(row);if(!row.error&&(phase==='direct'||row.result!=='否'))targets.push(i)}
  session.running=true;session.stage=phase;save();
  function paint(){table.removeAllRows();let row=new UITableRow();row.height=90;row.addText((phase==='direct'?'大陆':'境外')+'检测 '+done+'/'+targets.length,current);table.addRow(row);row=new UITableRow();row.height=70;row.addText(completed?'已结束，点击“完成”返回菜单':'停止后续检测','当前请求会在完成或超时后结束；点击“完成”也会停止。');row.dismissOnSelect=false;row.onSelect=()=>{stopped=true;current='正在停止，请等待当前请求结束…';paint()};table.addRow(row);table.reload()}
  paint();const presented=table.present(false).then(()=>{stopped=true});
  const probe=url=>nativeProbe(url,u=>new Request(u),classifier,session.timeout,()=>stopped,session.network||'');
  try{
   if(session.control){const u=await bridge('normalize',[session.control]);const controls=await nativeCheck(u,'proxy',probe,wait,()=>stopped);if(!controls.some(a=>a.status>0))throw Error('连通检查未取得 HTTP 响应，请核对网络或检查网址。')}
   for(const i of targets){if(stopped)break;current=session.rows[i].url;paint();const evidence=await nativeCheck(current,phase,probe,wait,()=>stopped);session.rows[i][phase==='direct'?'direct':'proxy']=evidence;logic.refresh(session.rows[i]);done++;save();paint()}
   session.stage=stopped?'cancelled':phase+'_done';current=stopped?'已停止，未完成行保留待确认。':'本轮完成。点击“完成”后可查看、筛选或导出结果。';
  }catch(e){session.stage='failed';current='本轮停止：'+String(e.message||e)}
  finally{session.running=false;completed=true;save();paint();await presented}
 }
 if(session.stage==='interrupted')await alert('上轮检测中断','已保留完成的结果。未完成网址保持待确认，可重新检测。');
 while(true){
  const a=new Alert();a.title='站点访问对照 · iOS v2';a.message='本机独立检测 · '+session.rows.length+'条\n网络：'+(session.network||'未备注')+'\n状态：'+session.stage+'\n先测大陆，再切换境外出口运行第二轮。';
  for(const label of ['从剪贴板导入网址','导入 TXT 文件','检测大陆网络','检测境外网络','查看全部结果','只看大陆打不开、境外可打开','导出结果 CSV','导出详细依据','超时 / 网络备注 / 连通检查'])a.addAction(label);a.addCancelAction('退出');
  const action=await a.presentSheet();if(action<0)break;
  try{switch(action){case 0:await loadList(Pasteboard.pasteString());break;case 1:{const paths=await DocumentPicker.open(['public.plain-text']);if(paths.length)await loadList(fm.readString(paths[0]));break}case 2:await run('direct');break;case 3:await run('proxy');break;case 4:await showResults();break;case 5:await showResults(true);break;case 6:case 7:{const choice=await alert('导出范围','导出全部结果或仅导出目标网址。',['全部结果','仅目标网址']);if(choice<0)break;const rows=session.rows.map(logic.refresh).filter(r=>choice===0||r.result==='是');await DocumentPicker.exportString(logic.exportCSV(rows,action===7),'site-results'+(action===7?'-detail':'')+'.csv');break}case 8:await settings();break}}catch(e){await alert('操作未完成',String(e.message||e))}
 }
}
await iosMain();
Script.complete();
