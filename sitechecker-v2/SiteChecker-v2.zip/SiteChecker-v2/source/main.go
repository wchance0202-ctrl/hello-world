package main

import (
	"crypto/rand"
	_ "embed"
	"encoding/hex"
	"flag"
	"fmt"
	"net"
	"net/http"
	"os"
	"os/exec"
	"os/signal"
	"runtime"
	"time"
)

//go:embed index.html
var indexHTML string

func main() {
	noBrowser := flag.Bool("no-browser", false, "Do not open a browser")
	flag.Parse()
	key := make([]byte, 24)
	if _, e := rand.Read(key); e != nil {
		panic(e)
	}
	token := hex.EncodeToString(key)
	ln, e := net.Listen("tcp4", "127.0.0.1:0")
	if e != nil {
		fmt.Println(e)
		os.Exit(1)
	}
	raw := "http://" + ln.Addr().String() + "/" + token + "/"
	app := NewApp(token)
	server := &http.Server{Handler: app.Handler(), ReadHeaderTimeout: 5 * time.Second, ReadTimeout: 15 * time.Second, IdleTimeout: 60 * time.Second, MaxHeaderBytes: 8192}
	fmt.Println("Site Checker v2.0 | Local mode")
	fmt.Println("Open this local address if your browser does not open:")
	fmt.Println(raw)
	fmt.Println("Keep this window open while checking. Close it to stop.")
	if !*noBrowser {
		switch runtime.GOOS {
		case "windows":
			_ = exec.Command("rundll32.exe", "url.dll,FileProtocolHandler", raw).Start()
		case "android":
			_ = exec.Command("termux-open-url", raw).Start()
		case "darwin":
			_ = exec.Command("open", raw).Start()
		default:
			_ = exec.Command("xdg-open", raw).Start()
		}
	}
	stop := make(chan os.Signal, 1)
	signal.Notify(stop, os.Interrupt)
	go func() {
		<-stop
		app.mu.Lock()
		if app.cancel != nil {
			app.cancel()
		}
		app.mu.Unlock()
		server.Close()
	}()
	if e := server.Serve(ln); e != nil && e != http.ErrServerClosed {
		fmt.Println(e)
	}
}
