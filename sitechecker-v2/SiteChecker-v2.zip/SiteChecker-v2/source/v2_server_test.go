package main

import (
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"strings"
	"sync/atomic"
	"testing"
	"time"
)

func TestV2PagedStateDoesNotSendAllEvidence(t *testing.T) {
	app := NewApp("t")
	app.state.Rows = ParseList(strings.Repeat("example.com\n", 250))
	app.state.Rows[0].Direct = []Attempt{{Kind: "usable", Detail: "private-diagnostic"}}
	RefreshRow(&app.state.Rows[0])
	s := httptest.NewServer(app.Handler())
	defer s.Close()
	code, b := requestAPI(t, s, "GET", "/t/api/state?page=2&limit=100", "")
	var v struct {
		Rows          []Row `json:"rows"`
		FilteredTotal int   `json:"filtered_total"`
	}
	json.Unmarshal(b, &v)
	if code != 200 || len(v.Rows) != 100 || v.FilteredTotal != 250 || strings.Contains(string(b), "private-diagnostic") {
		t.Fatalf("bad page: %d %d %d", code, len(v.Rows), v.FilteredTotal)
	}
}
func TestV2MacProxyParsing(t *testing.T) {
	got := ParseMacProxy("<dictionary> {\n HTTPEnable : 1\n HTTPProxy : 127.0.0.1\n HTTPPort : 8111\n HTTPSEnable : 1\n HTTPSProxy : ::1\n HTTPSPort : 8112\n}")
	if got != "http=127.0.0.1:8111;https=[::1]:8112" {
		t.Fatal(got)
	}
}
func TestV2RecoveredDirectRecheckRemovesTargetConclusion(t *testing.T) {
	r := Row{Direct: []Attempt{{Kind: "transport"}, {Kind: "transport"}, {Kind: "transport"}}, Proxy: []Attempt{{Kind: "usable"}, {Kind: "usable"}}}
	r.Recheck = []Attempt{{Kind: "usable"}}
	RefreshRow(&r)
	if r.Conclusion != "大陆复测可打开" || r.Result == "是" {
		t.Fatal(r)
	}
}
func TestV2OldBaselineIsNotFreshEvidence(t *testing.T) {
	r := Row{Direct: []Attempt{{Kind: "transport"}, {Kind: "transport"}, {Kind: "transport", At: time.Now().Add(-time.Hour).Format(time.RFC3339)}}, Proxy: []Attempt{{Kind: "usable", At: time.Now().Format(time.RFC3339)}, {Kind: "usable"}}}
	RefreshRow(&r)
	if r.Conclusion != "需更新大陆检测" {
		t.Fatal(r)
	}
}
func TestV2TUNCannotUseDirectRecheck(t *testing.T) {
	app := NewApp("t")
	app.state.Stage = "direct_done"
	app.state.Rows = ParseList("example.com")
	s := httptest.NewServer(app.Handler())
	defer s.Close()
	code, _ := requestAPI(t, s, "POST", "/t/api/start", `{"phase":"proxy","confirm":true,"mode":"tun","recheck":true,"no_tun":true}`)
	if code != http.StatusBadRequest {
		t.Fatal(code)
	}
}

func TestV2APIActuallyRechecksDirectRoute(t *testing.T) {
	var calls atomic.Int32
	target := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if calls.Add(1) <= 3 {
			c, _, e := w.(http.Hijacker).Hijack()
			if e != nil {
				t.Error(e)
				return
			}
			c.Close()
			return
		}
		w.Header().Set("Content-Type", "text/html")
		w.Write([]byte("<html><body>Recovered</body></html>"))
	}))
	defer target.Close()
	proxy := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "text/html")
		w.Write([]byte("<html><body>Proxy response</body></html>"))
	}))
	defer proxy.Close()
	app := NewApp("t")
	s := httptest.NewServer(app.Handler())
	defer s.Close()
	wait := func() {
		deadline := time.Now().Add(10 * time.Second)
		for time.Now().Before(deadline) {
			if !app.snapshot().Running {
				return
			}
			time.Sleep(10 * time.Millisecond)
		}
		t.Fatal("phase timeout")
	}
	b, _ := json.Marshal(StartRequest{Phase: "direct", Text: target.URL, Confirm: true, Timeout: 2})
	code, body := requestAPI(t, s, "POST", "/t/api/start", string(b))
	if code != 200 {
		t.Fatal(code, string(body))
	}
	wait()
	b, _ = json.Marshal(StartRequest{Phase: "proxy", Confirm: true, Mode: "manual", Proxy: proxy.URL, Timeout: 2, Recheck: true, NoTUN: true})
	code, body = requestAPI(t, s, "POST", "/t/api/start", string(b))
	if code != 200 {
		t.Fatal(code, string(body))
	}
	wait()
	r := app.snapshot().Rows[0]
	if len(r.Recheck) == 0 || r.Conclusion != "大陆复测可打开" || r.Result == "是" {
		t.Fatalf("missing recheck: %+v", r)
	}
}
