package main

import (
	"context"
	"encoding/json"
	"net"
	"net/http"
	"net/url"
	"runtime"
	"strconv"
	"strings"
	"sync"
	"time"
)

type State struct {
	Rows     []Row  `json:"rows"`
	Running  bool   `json:"running"`
	Stage    string `json:"stage"`
	Done     int    `json:"done"`
	Total    int    `json:"total"`
	Message  string `json:"message"`
	Revision uint64 `json:"revision"`
	Mode     string `json:"mode"`
	Network  string `json:"network"`
}
type App struct {
	mu     sync.Mutex
	state  State
	token  string
	cancel context.CancelFunc
}

func NewApp(token string) *App {
	return &App{token: token, state: State{Rows: []Row{}, Stage: "ready", Message: "粘贴网址，先检测大陆网络。", Revision: 1}}
}
func cloneRow(r Row) Row {
	r.Direct = append([]Attempt{}, r.Direct...)
	r.Proxy = append([]Attempt{}, r.Proxy...)
	r.Recheck = append([]Attempt{}, r.Recheck...)
	return r
}
func (a *App) snapshot() State {
	a.mu.Lock()
	defer a.mu.Unlock()
	s := a.state
	s.Rows = make([]Row, len(a.state.Rows))
	for i, r := range a.state.Rows {
		s.Rows[i] = cloneRow(r)
	}
	return s
}
func writeJSON(w http.ResponseWriter, v any) {
	w.Header().Set("Content-Type", "application/json; charset=utf-8")
	json.NewEncoder(w).Encode(v)
}
func fail(w http.ResponseWriter, code int, msg string) {
	w.Header().Set("Content-Type", "application/json; charset=utf-8")
	w.WriteHeader(code)
	json.NewEncoder(w).Encode(map[string]string{"error": msg})
}
func matchesFilter(r Row, f string) bool {
	switch f {
	case "target":
		return r.Conclusion == "大陆打不开，境外可打开"
	case "direct":
		return r.Conclusion == "大陆可打开" || r.Conclusion == "大陆复测可打开"
	case "both":
		return r.Conclusion == "两边都无法连接"
	case "unknown":
		return r.Conclusion == "待确认" || r.Conclusion == "需更新大陆检测"
	}
	return true
}

type rowView struct {
	Row
	Index int `json:"index"`
}

func (a *App) pagedState(w http.ResponseWriter, r *http.Request) {
	a.mu.Lock()
	defer a.mu.Unlock()
	if since := r.URL.Query().Get("since"); since != "" && since == strconv.FormatUint(a.state.Revision, 10) {
		writeJSON(w, map[string]any{"unchanged": true, "revision": a.state.Revision})
		return
	}
	page, _ := strconv.Atoi(r.URL.Query().Get("page"))
	if page < 1 {
		page = 1
	}
	limit, _ := strconv.Atoi(r.URL.Query().Get("limit"))
	if limit < 1 || limit > 200 {
		limit = 100
	}
	f := r.URL.Query().Get("filter")
	indices := []int{}
	counts := map[string]int{"target": 0, "direct": 0, "both": 0, "unknown": 0}
	for i, row := range a.state.Rows {
		for key := range counts {
			if matchesFilter(row, key) {
				counts[key]++
			}
		}
		if matchesFilter(row, f) {
			indices = append(indices, i)
		}
	}
	if max := (len(indices) + limit - 1) / limit; max > 0 && page > max {
		page = max
	}
	views := []rowView{}
	for n := (page - 1) * limit; n < len(indices) && n < page*limit; n++ {
		i := indices[n]
		row := a.state.Rows[i]
		row.Direct = nil
		row.Proxy = nil
		row.Recheck = nil
		views = append(views, rowView{Row: row, Index: i})
	}
	writeJSON(w, map[string]any{"rows": views, "running": a.state.Running, "stage": a.state.Stage, "done": a.state.Done, "total": a.state.Total, "message": a.state.Message, "revision": a.state.Revision, "mode": a.state.Mode, "network": a.state.Network, "platform": runtime.GOOS, "counts": counts, "total_rows": len(a.state.Rows), "filtered_total": len(indices), "page": page, "limit": limit})
}
func (a *App) Handler() http.Handler {
	prefix := "/" + a.token + "/"
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Cache-Control", "no-store")
		w.Header().Set("X-Content-Type-Options", "nosniff")
		w.Header().Set("Referrer-Policy", "no-referrer")
		w.Header().Set("Content-Security-Policy", "default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; connect-src 'self'; img-src 'self' data:; frame-ancestors 'none'; base-uri 'none'; form-action 'self'")
		host := r.Host
		if h, _, e := net.SplitHostPort(r.Host); e == nil {
			host = h
		}
		if host != "127.0.0.1" && host != "localhost" && host != "::1" {
			http.Error(w, "Local access only", 403)
			return
		}
		if !strings.HasPrefix(r.URL.Path, prefix) {
			http.NotFound(w, r)
			return
		}
		if origin := r.Header.Get("Origin"); origin != "" && origin != "http://"+r.Host {
			http.Error(w, "Origin rejected", 403)
			return
		}
		path := strings.TrimPrefix(r.URL.Path, prefix)
		switch {
		case path == "" && r.Method == "GET":
			w.Header().Set("Content-Type", "text/html; charset=utf-8")
			w.Write([]byte(indexHTML))
		case path == "api/state" && r.Method == "GET":
			if r.URL.Query().Get("limit") != "" {
				a.pagedState(w, r)
			} else {
				writeJSON(w, a.snapshot())
			}
		case path == "api/evidence" && r.Method == "GET":
			i, e := strconv.Atoi(r.URL.Query().Get("index"))
			a.mu.Lock()
			if e != nil || i < 0 || i >= len(a.state.Rows) {
				a.mu.Unlock()
				fail(w, 400, "行号无效")
				return
			}
			row := cloneRow(a.state.Rows[i])
			a.mu.Unlock()
			writeJSON(w, row)
		case path == "api/start" && r.Method == "POST":
			a.start(w, r)
		case path == "api/cancel" && r.Method == "POST":
			a.mu.Lock()
			if a.cancel != nil {
				a.cancel()
				a.state.Message = "正在取消…"
				a.state.Revision++
			}
			a.mu.Unlock()
			writeJSON(w, map[string]bool{"ok": true})
		case path == "api/export" && r.Method == "GET":
			s := a.snapshot()
			rows := []Row{}
			for _, row := range s.Rows {
				if matchesFilter(row, r.URL.Query().Get("filter")) {
					rows = append(rows, row)
				}
			}
			w.Header().Set("Content-Type", "text/csv; charset=utf-8")
			w.Header().Set("Content-Disposition", `attachment; filename="site-results.csv"`)
			w.Write(ExportCSV(rows, r.URL.Query().Get("detail") == "1"))
		default:
			http.NotFound(w, r)
		}
	})
}

type StartRequest struct {
	Phase      string `json:"phase"`
	Text       string `json:"text"`
	Confirm    bool   `json:"confirm"`
	Mode       string `json:"mode"`
	Proxy      string `json:"proxy"`
	Timeout    int    `json:"timeout"`
	Recheck    bool   `json:"recheck"`
	NoTUN      bool   `json:"no_tun"`
	Network    string `json:"network"`
	ControlURL string `json:"control_url"`
}

func (a *App) start(w http.ResponseWriter, r *http.Request) {
	var q StartRequest
	r.Body = http.MaxBytesReader(w, r.Body, 4*1024*1024)
	if e := json.NewDecoder(r.Body).Decode(&q); e != nil {
		fail(w, 400, "输入太大或格式错误")
		return
	}
	if !q.Confirm {
		fail(w, 400, "请先确认当前网络与代理状态")
		return
	}
	if q.Phase != "direct" && q.Phase != "proxy" {
		fail(w, 400, "未知检测阶段")
		return
	}
	if q.Timeout == 0 {
		q.Timeout = 12
	}
	if q.Timeout < 2 || q.Timeout > 60 {
		fail(w, 400, "超时应为2–60秒")
		return
	}
	if q.Recheck && (q.Phase != "proxy" || q.Mode == "tun" || !q.NoTUN) {
		fail(w, 400, "直连复测仅适用于显式代理，并需确认系统没有开启 VPN/TUN")
		return
	}
	if len(q.Network) > 200 {
		fail(w, 400, "网络备注过长")
		return
	}
	if q.ControlURL != "" {
		u, e := Normalize(q.ControlURL)
		if e != nil {
			fail(w, 400, "连通检查网址无效")
			return
		}
		q.ControlURL = u
	}
	a.mu.Lock()
	defer a.mu.Unlock()
	if a.state.Running {
		fail(w, 409, "上一轮尚未结束，请等待或取消")
		return
	}
	if q.Phase == "proxy" && a.state.Stage != "direct_done" && a.state.Stage != "proxy_done" && a.state.Stage != "cancelled" && a.state.Stage != "failed" {
		fail(w, 400, "请先检测大陆网络")
		return
	}
	rows := a.state.Rows
	if q.Phase == "direct" {
		rows = ParseList(q.Text)
		if len(rows) == 0 || len(rows) > 5000 {
			fail(w, 400, "请输入1–5000条网址")
			return
		}
	}
	if q.Phase == "proxy" && len(rows) == 0 {
		fail(w, 400, "没有可对照的大陆结果")
		return
	}
	proxy := ""
	if q.Phase == "proxy" {
		switch q.Mode {
		case "auto":
			var e error
			proxy, e = DetectProxy()
			if e != nil {
				fail(w, 400, e.Error())
				return
			}
		case "manual":
			proxy = strings.TrimSpace(q.Proxy)
			if proxy == "" {
				fail(w, 400, "请输入代理地址")
				return
			}
		case "tun":
		default:
			fail(w, 400, "请选择境外网络方式")
			return
		}
	} else {
		q.Mode = "direct"
	}
	client, e := NewClient(proxy, time.Duration(q.Timeout)*time.Second)
	if e != nil {
		fail(w, 400, e.Error())
		return
	}
	indices := []int{}
	for i := range rows {
		if rows[i].Error != "" {
			continue
		}
		if q.Phase == "proxy" {
			rows[i].Proxy = []Attempt{}
			rows[i].Recheck = nil
			RefreshRow(&rows[i])
			if rows[i].Result == "否" {
				continue
			}
		}
		indices = append(indices, i)
	}
	ctx, cancel := context.WithCancel(context.Background())
	a.cancel = cancel
	label := "大陆"
	if q.Phase == "proxy" {
		label = "境外"
	}
	a.state = State{Rows: rows, Running: true, Stage: q.Phase, Total: len(indices), Message: label + "检测中；请勿切换网络。", Revision: a.state.Revision + 1, Mode: q.Mode, Network: q.Network}
	go a.run(ctx, client, q, indices, cancel)
	writeJSON(w, map[string]bool{"ok": true})
}
func (a *App) run(ctx context.Context, client *http.Client, q StartRequest, indices []int, cancel context.CancelFunc) {
	defer cancel()
	defer client.CloseIdleConnections()
	failure := ""
	defer func() {
		a.mu.Lock()
		defer a.mu.Unlock()
		a.cancel = nil
		a.state.Running = false
		a.state.Revision++
		if ctx.Err() != nil {
			a.state.Stage = "cancelled"
			a.state.Message = "已取消。未完成的行保留待确认。"
		} else if failure != "" {
			a.state.Stage = "failed"
			a.state.Message = failure
		} else {
			a.state.Stage = q.Phase + "_done"
			if q.Phase == "direct" {
				a.state.Message = "大陆检测完成。切换到境外出口后，开始第二步。"
			} else {
				a.state.Message = "对照完成，可筛选目标并导出。"
			}
		}
	}()
	urls := []string{}
	for _, i := range indices {
		urls = append(urls, a.state.Rows[i].URL)
	}
	if q.Phase == "proxy" && q.Mode != "tun" && len(urls) > 0 {
		if e := ProxyPreflight(ctx, client, urls); e != nil {
			failure = e.Error()
			return
		}
	}
	if q.ControlURL != "" {
		evidence := Check(ctx, client, q.ControlURL, 2, 1, 300*time.Millisecond)
		responded := false
		for _, v := range evidence {
			if v.Status > 0 {
				responded = true
			}
		}
		if !responded {
			failure = "连通检查网址没有返回 HTTP 响应，已暂停本轮。请核对网络、代理或更换已知可用的检查网址。"
			return
		}
	}
	var direct *http.Client
	if q.Recheck {
		direct, _ = NewClient("", time.Duration(q.Timeout)*time.Second)
		defer direct.CloseIdleConnections()
	}
	hosts := map[string]chan struct{}{}
	for _, raw := range urls {
		u, _ := url.Parse(raw)
		if hosts[u.Hostname()] == nil {
			hosts[u.Hostname()] = make(chan struct{}, 2)
		}
	}
	jobs := make(chan int)
	var wg sync.WaitGroup
	workers := 6
	if len(indices) < workers {
		workers = len(indices)
	}
	for n := 0; n < workers; n++ {
		wg.Add(1)
		go func() {
			defer wg.Done()
			for i := range jobs {
				if ctx.Err() != nil {
					return
				}
				a.mu.Lock()
				u := a.state.Rows[i].URL
				baseline := append([]Attempt{}, a.state.Rows[i].Direct...)
				a.mu.Unlock()
				parsed, _ := url.Parse(u)
				sem := hosts[parsed.Hostname()]
				select {
				case sem <- struct{}{}:
				case <-ctx.Done():
					return
				}
				max, required := 3, 1
				if q.Phase == "proxy" {
					max, required = 2, 2
				}
				evidence := Check(ctx, client, u, max, required, 700*time.Millisecond)
				for j := range evidence {
					evidence[j].Mode = q.Mode
					evidence[j].Network = q.Network
				}
				var recheck []Attempt
				if direct != nil {
					if result, _ := Decision(baseline, evidence); result == "是" {
						recheck = Check(ctx, direct, u, 3, 1, 700*time.Millisecond)
						for j := range recheck {
							recheck[j].Mode = "direct_recheck"
							recheck[j].Network = "系统无TUN（用户确认）"
						}
					}
				}
				<-sem
				a.mu.Lock()
				if q.Phase == "direct" {
					a.state.Rows[i].Direct = evidence
				} else {
					a.state.Rows[i].Proxy = evidence
					a.state.Rows[i].Recheck = recheck
				}
				RefreshRow(&a.state.Rows[i])
				a.state.Done++
				a.state.Revision++
				a.mu.Unlock()
			}
		}()
	}
dispatch:
	for _, i := range indices {
		select {
		case jobs <- i:
		case <-ctx.Done():
			break dispatch
		}
	}
	close(jobs)
	wg.Wait()
}
