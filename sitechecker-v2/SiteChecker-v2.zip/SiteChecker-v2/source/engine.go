package main

import (
	"bytes"
	"context"
	"crypto/tls"
	"crypto/x509"
	"encoding/csv"
	"errors"
	"fmt"
	"io"
	"net"
	"net/http"
	"net/url"
	"regexp"
	"strconv"
	"strings"
	"time"
)

type Attempt struct {
	Kind         string   `json:"kind"`
	Status       int      `json:"status,omitempty"`
	Note         string   `json:"note"`
	ElapsedMS    int64    `json:"elapsed_ms"`
	At           string   `json:"at"`
	FinalURL     string   `json:"final_url,omitempty"`
	Redirects    []string `json:"redirects,omitempty"`
	Title        string   `json:"title,omitempty"`
	Stage        string   `json:"error_stage,omitempty"`
	Detail       string   `json:"detail,omitempty"`
	Truncated    bool     `json:"truncated,omitempty"`
	BytesRead    int      `json:"bytes_read,omitempty"`
	RetryAfterMS int64    `json:"retry_after_ms,omitempty"`
	Mode         string   `json:"mode,omitempty"`
	Network      string   `json:"network,omitempty"`
}
type Row struct {
	Input      string    `json:"input"`
	URL        string    `json:"url"`
	Error      string    `json:"error,omitempty"`
	Direct     []Attempt `json:"direct"`
	Proxy      []Attempt `json:"proxy"`
	Recheck    []Attempt `json:"recheck,omitempty"`
	Result     string    `json:"result"`
	Reason     string    `json:"reason"`
	Mainland   string    `json:"mainland"`
	Overseas   string    `json:"overseas"`
	Conclusion string    `json:"conclusion"`
}

var urlInText = regexp.MustCompile(`(?i)https?://[^\s<>"\x60|]+`)
var schemeRE = regexp.MustCompile(`^[a-zA-Z][a-zA-Z0-9+.-]*://`)
var bareDomain = regexp.MustCompile(`(?i)^(localhost|[a-z0-9\p{Han}][a-z0-9.\-\p{Han}]*\.[a-z\p{Han}]{2,}|[0-9]+(?:\.[0-9]+){3}|\[[0-9a-f:]+\])(?::[0-9]{1,5})?(?:[/\?#][^\s]*)?$`)

func Normalize(raw string) (string, error) {
	s := strings.TrimSpace(strings.TrimPrefix(strings.TrimSpace(raw), "\ufeff"))
	if !schemeRE.MatchString(s) {
		if !bareDomain.MatchString(s) {
			return "", errors.New("请输入完整网址或有效域名")
		}
		s = "https://" + s
	}
	u, err := url.Parse(s)
	if err != nil || u == nil || u.Hostname() == "" || (strings.ToLower(u.Scheme) != "http" && strings.ToLower(u.Scheme) != "https") || strings.ContainsAny(u.Host, " \t\r\n") {
		return "", errors.New("网址格式无效，仅支持 HTTP / HTTPS")
	}
	if u.User != nil {
		return "", errors.New("网址不能包含用户名或密码")
	}
	if p := u.Port(); p != "" {
		n, e := strconv.Atoi(p)
		if e != nil || n < 1 || n > 65535 {
			return "", errors.New("端口无效")
		}
	}
	u.Scheme = strings.ToLower(u.Scheme)
	u.Host = strings.ToLower(u.Host)
	return u.String(), nil
}
func ParseList(text string) []Row {
	rows := []Row{}
	for _, line := range strings.Split(strings.ReplaceAll(text, "\r\n", "\n"), "\n") {
		line = strings.TrimSpace(strings.TrimPrefix(line, "\ufeff"))
		if line == "" {
			continue
		}
		candidates := []string{line}
		extracted := false
		if _, e := Normalize(line); e != nil {
			// Extract only explicitly formatted Markdown/prose; keep invalid raw URLs intact.
			if strings.Contains(line, "](") || (!schemeRE.MatchString(line) && strings.ContainsAny(line, " \t")) {
				if matches := urlInText.FindAllString(line, -1); len(matches) > 0 {
					candidates = matches
					extracted = true
				}
			}
		}
		for _, candidate := range candidates {
			if extracted && strings.Contains(line, "](") {
				candidate = strings.TrimSuffix(candidate, ")")
			}
			u, e := Normalize(candidate)
			r := Row{Input: line, URL: u, Direct: []Attempt{}, Proxy: []Attempt{}, Result: "待确认", Reason: "尚未检测"}
			if e != nil {
				r.Error = e.Error()
			}
			RefreshRow(&r)
			rows = append(rows, r)
		}
	}
	return rows
}
func NewClient(proxy string, timeout time.Duration) (*http.Client, error) {
	tr := &http.Transport{Proxy: nil, DialContext: (&net.Dialer{Timeout: timeout, KeepAlive: 15 * time.Second}).DialContext, TLSHandshakeTimeout: timeout, ResponseHeaderTimeout: timeout, MaxIdleConns: 32, MaxIdleConnsPerHost: 2, MaxConnsPerHost: 2, IdleConnTimeout: 20 * time.Second, TLSClientConfig: &tls.Config{MinVersion: tls.VersionTLS12}, ForceAttemptHTTP2: true}
	if proxy != "" {
		resolver, e := ProxyResolver(proxy)
		if e != nil {
			return nil, e
		}
		tr.Proxy = resolver
	}
	return &http.Client{Transport: tr, Timeout: timeout, CheckRedirect: func(req *http.Request, via []*http.Request) error {
		if len(via) >= 10 {
			return errors.New("跳转次数超过10次")
		}
		return nil
	}}, nil
}

const bodyLimit = 512 * 1024

func Probe(ctx context.Context, client *http.Client, raw string) (a Attempt) {
	start := time.Now()
	a.At = start.Format(time.RFC3339)
	defer func() { a.ElapsedMS = time.Since(start).Milliseconds() }()
	req, err := http.NewRequestWithContext(ctx, "GET", raw, nil)
	if err != nil {
		a.Kind = "input"
		a.Stage = "input"
		a.Note = "网址无效"
		return
	}
	req.Header.Set("User-Agent", "Mozilla/5.0 (compatible; SiteChecker/2.0; local reachability check)")
	req.Header.Set("Accept", "text/html,application/xhtml+xml,application/json,text/plain;q=0.9,*/*;q=0.8")
	req.Header.Set("Accept-Language", "zh-CN,zh;q=0.9,en;q=0.8")
	// Copy the client, so simultaneous probes can record their own redirect chains.
	local := *client
	redirect := client.CheckRedirect
	local.CheckRedirect = func(r *http.Request, via []*http.Request) error {
		a.Redirects = append(a.Redirects, r.URL.Redacted())
		if redirect != nil {
			return redirect(r, via)
		}
		if len(via) >= 10 {
			return errors.New("跳转次数超过10次")
		}
		return nil
	}
	resp, err := local.Do(req)
	if err != nil {
		a.Kind = "transport"
		a.Stage = "connection"
		a.Note = "网络连接失败"
		a.Detail = safeError(err)
		if ctx.Err() != nil {
			a.Kind = "cancelled"
			a.Stage = "cancelled"
			a.Note = "检测已取消"
			return
		}
		var cert *tls.CertificateVerificationError
		var unknown x509.UnknownAuthorityError
		var host x509.HostnameError
		var invalid x509.CertificateInvalidError
		var dns *net.DNSError
		var op *net.OpError
		var ne net.Error
		switch {
		case errors.As(err, &cert) || errors.As(err, &unknown) || errors.As(err, &host) || errors.As(err, &invalid):
			a.Kind = "tls"
			a.Stage = "tls"
			a.Note = "证书验证失败"
		case strings.HasPrefix(strings.ToLower(a.Detail), "tls:") || strings.Contains(strings.ToLower(a.Detail), ": tls:"):
			a.Kind = "tls"
			a.Stage = "tls"
			a.Note = "TLS 协议协商失败，需复核"
		case strings.Contains(err.Error(), "跳转次数"):
			a.Kind = "http"
			a.Stage = "redirect"
			a.Note = "网页跳转循环"
		case errors.As(err, &dns):
			a.Stage = "dns"
			a.Note = "DNS 解析失败"
		case errors.As(err, &ne) && ne.Timeout():
			a.Stage = "timeout"
			a.Note = "请求超时"
		case errors.As(err, &op):
			a.Stage = "tcp"
			a.Note = "TCP 连接失败 / 中断"
		default:
			a.Kind = "protocol"
			a.Stage = "protocol"
			a.Note = "请求或协议异常，需复核"
		}
		// EOF before headers is a network termination, not malformed input.
		if errors.Is(err, io.EOF) || errors.Is(err, io.ErrUnexpectedEOF) {
			a.Kind = "transport"
			a.Stage = "connection"
			a.Note = "响应前连接中断"
		}
		return
	}
	defer resp.Body.Close()
	a.Status = resp.StatusCode
	a.FinalURL = resp.Request.URL.Redacted()
	if retry := resp.Header.Get("Retry-After"); retry != "" {
		if n, e := strconv.Atoi(retry); e == nil && n > 0 {
			a.RetryAfterMS = int64(n) * 1000
		} else if at, e := http.ParseTime(retry); e == nil && at.After(time.Now()) {
			a.RetryAfterMS = time.Until(at).Milliseconds()
		}
	}
	if resp.StatusCode < 200 || resp.StatusCode >= 300 {
		a.Kind = "http"
		a.Stage = "http"
		a.Note = fmt.Sprintf("HTTP %d：服务器已响应，目标页面未正常返回", resp.StatusCode)
		return
	}
	b, err := io.ReadAll(io.LimitReader(resp.Body, bodyLimit+1))
	a.BytesRead = len(b)
	if len(b) > bodyLimit {
		a.Truncated = true
		b = b[:bodyLimit]
		a.BytesRead = bodyLimit
	}
	if err != nil {
		a.Kind = "incomplete"
		a.Stage = "body"
		a.Note = "服务器已响应，但正文读取失败"
		a.Detail = safeError(err)
		if ctx.Err() != nil {
			a.Kind = "cancelled"
			a.Note = "检测已取消"
		}
		return
	}
	a.Kind, a.Note, a.Title = Classify(resp.Header.Get("Content-Type"), resp.Request.URL.Path, b, a.Truncated)
	if a.Truncated {
		a.Note += "；仅检查前512KB"
	}
	return
}
func safeError(err error) string {
	var u *url.Error
	if errors.As(err, &u) {
		return safeError(u.Err)
	}
	s := err.Error()
	// Proxy addresses can contain credentials; never return those to exports.
	re := regexp.MustCompile(`(?i)(https?|socks5h?)://[^\s/@]+:[^\s/@]+@`)
	s = re.ReplaceAllString(s, "proxy://[redacted]@")
	if len(s) > 500 {
		s = s[:500]
	}
	return s
}
func reachable(kind string) bool { return kind == "usable" || kind == "login" || kind == "js" }
func Check(ctx context.Context, c *http.Client, u string, maxAttempts, requiredSuccesses int, delay time.Duration) []Attempt {
	out := []Attempt{}
	success := 0
	for i := 0; i < maxAttempts; i++ {
		if ctx.Err() != nil {
			break
		}
		a := Probe(ctx, c, u)
		out = append(out, a)
		if reachable(a.Kind) {
			success++
		} else {
			success = 0
		}
		if success >= requiredSuccesses || a.Kind == "cancelled" {
			break
		}
		retryable := a.Kind == "transport" || (a.Kind == "http" && (a.Status == 429 || a.Status == 502 || a.Status == 503 || a.Status == 504))
		if !reachable(a.Kind) && !retryable {
			break
		}
		if i < maxAttempts-1 {
			pause := delay * time.Duration(1<<i)
			if wait := time.Duration(a.RetryAfterMS) * time.Millisecond; wait > pause {
				pause = wait
			}
			if pause > 30*time.Second {
				break
			} // Do not retry earlier than Retry-After.
			timer := time.NewTimer(pause)
			select {
			case <-ctx.Done():
				timer.Stop()
				return out
			case <-timer.C:
			}
		}
	}
	return out
}
func allNetwork(a []Attempt, min int) bool {
	if len(a) < min {
		return false
	}
	for _, v := range a {
		if v.Kind != "transport" {
			return false
		}
	}
	return true
}
func Decision(d, p []Attempt) (string, string) {
	for _, a := range d {
		if reachable(a.Kind) {
			return "否", "大陆线路已返回页面响应；仅代表本次线路与时间"
		}
	}
	if len(d) == 0 {
		return "待确认", "尚未检测大陆网络"
	}
	if !allNetwork(d, 3) {
		return "待确认", "大陆检测未得到完整网络失败证据，查看页面状态与详细依据"
	}
	if len(p) >= 2 && reachable(p[len(p)-1].Kind) && reachable(p[len(p)-2].Kind) {
		return "是", "本次大陆连续3次网络失败，境外连续2次页面可连接；网络出口由用户确认，不认定封锁原因"
	}
	if len(p) == 0 {
		return "待确认", "大陆连续3次网络失败，等待境外对照"
	}
	return "待确认", "境外未连续2次可连接，无法确定访问差异"
}
func NetworkStatus(a []Attempt, min int) string {
	for _, v := range a {
		switch v.Kind {
		case "usable":
			return "可访问"
		case "login":
			return "可连接（登录页）"
		case "js":
			return "可连接（JS页面）"
		}
	}
	if len(a) == 0 {
		return "未检测"
	}
	if allNetwork(a, min) {
		return "无法连接"
	}
	v := a[len(a)-1]
	switch v.Kind {
	case "http":
		return fmt.Sprintf("HTTP %d（待确认）", v.Status)
	case "tls":
		return "证书异常"
	case "challenge":
		return "验证码 / 访问受限"
	case "page_error":
		return "站点错误页"
	case "cancelled":
		return "已取消"
	case "empty":
		return "空响应"
	case "transport":
		return "失败样本不足"
	case "incomplete":
		return "响应不完整"
	}
	return "待确认"
}
func RefreshRow(r *Row) {
	r.Mainland = NetworkStatus(r.Direct, 3)
	r.Overseas = NetworkStatus(r.Proxy, 2)
	r.Conclusion = "待确认"
	if r.Error != "" {
		r.Result = "待确认"
		r.Reason = r.Error
		r.Mainland = "输入无效"
		return
	}
	r.Result, r.Reason = Decision(r.Direct, r.Proxy)
	switch {
	case r.Result == "否":
		r.Conclusion = "大陆可打开"
	case r.Result == "是":
		r.Conclusion = "大陆打不开，境外可打开"
	case allNetwork(r.Direct, 3) && allNetwork(r.Proxy, 2):
		r.Conclusion = "两边都无法连接"
	}
	for _, v := range r.Recheck {
		if reachable(v.Kind) {
			r.Conclusion = "大陆复测可打开"
			r.Result = "待确认"
			r.Reason = "境外对照期间，大陆直连复测也成功；原失败可能是临时故障"
			return
		}
	}
	if r.Result == "是" && len(r.Recheck) > 0 && !allNetwork(r.Recheck, 1) {
		r.Result = "待确认"
		r.Conclusion = "待确认"
		r.Reason = "大陆复测状态不明确，不能确认访问差异"
	}
	if r.Result == "是" && len(r.Direct) > 0 && len(r.Proxy) > 0 {
		d, e1 := time.Parse(time.RFC3339, r.Direct[len(r.Direct)-1].At)
		p, e2 := time.Parse(time.RFC3339, r.Proxy[0].At)
		if e1 == nil && e2 == nil && p.Sub(d) > 30*time.Minute && len(r.Recheck) == 0 {
			r.Result = "待确认"
			r.Conclusion = "需更新大陆检测"
			r.Reason = "两轮间隔超过30分钟；重新检测大陆网络后再对照"
		}
	}
}
func csvSafe(s string) string {
	trim := strings.TrimLeft(s, " \t\r\n")
	if trim != "" && strings.ContainsAny(trim[:1], "=+-@") {
		return "'" + s
	}
	return s
}
func attemptSummary(a []Attempt) string {
	parts := []string{}
	for _, v := range a {
		parts = append(parts, fmt.Sprintf("%s [%s] HTTP=%d %s (%dms) final=%s redirects=%s title=%s stage=%s error=%s truncated=%t bytes=%d mode=%s network=%s", v.At, v.Kind, v.Status, v.Note, v.ElapsedMS, v.FinalURL, strings.Join(v.Redirects, " -> "), v.Title, v.Stage, v.Detail, v.Truncated, v.BytesRead, v.Mode, v.Network))
	}
	return strings.Join(parts, " | ")
}
func ExportCSV(rows []Row, detail bool) []byte {
	var b bytes.Buffer
	b.WriteString("\xef\xbb\xbf")
	w := csv.NewWriter(&b)
	w.UseCRLF = true
	head := []string{"网址", "大陆网络", "境外网络", "对照结论"}
	if detail {
		head = append(head, "原始输入", "判断依据", "大陆证据", "境外证据", "大陆复测证据")
	}
	w.Write(head)
	for _, r := range rows {
		RefreshRow(&r)
		u := r.URL
		if u == "" {
			u = r.Input
		}
		rec := []string{u, r.Mainland, r.Overseas, r.Conclusion}
		if detail {
			rec = append(rec, r.Input, r.Reason, attemptSummary(r.Direct), attemptSummary(r.Proxy), attemptSummary(r.Recheck))
		}
		for i := range rec {
			rec[i] = csvSafe(rec[i])
		}
		w.Write(rec)
	}
	w.Flush()
	return b.Bytes()
}
