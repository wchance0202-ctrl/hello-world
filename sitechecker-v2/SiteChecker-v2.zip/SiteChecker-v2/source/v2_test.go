package main

import (
	"context"
	"io"
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"
)

func TestV2WholeInputBeforeEmbeddedURL(t *testing.T) {
	input := "example.com/redirect?next=https://other.example/path"
	rows := ParseList(input)
	if len(rows) != 1 || rows[0].URL != "https://"+input || rows[0].Input != input {
		t.Fatalf("wrong target: %+v", rows)
	}
}

func TestV2ReachabilityClassification(t *testing.T) {
	cases := []struct{ name, body, kind string }{
		{"short", `<html><title>Hello</title><body>Hi</body></html>`, "usable"},
		{"login", `<html><body><input type="password"></body></html>`, "login"},
		{"js", `<html><body><div id="app"></div><script>boot()</script></body></html>`, "js"},
		{"truncated_script", `<html><body><script>` + strings.Repeat("x", 600*1024) + `</script></body></html>`, "js"},
		{"soft_error", `<html><title>Service Unavailable</title><body>` + strings.Repeat("Please try again later. ", 8) + `</body></html>`, "page_error"},
		{"ordinary_article", `<html><title>Research about access denied errors</title><body>How to diagnose errors in your application.</body></html>`, "usable"},
	}
	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			s := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
				w.Header().Set("Content-Type", "text/html")
				io.WriteString(w, tc.body)
			}))
			defer s.Close()
			a := Probe(context.Background(), s.Client(), s.URL)
			if a.Kind != tc.kind {
				t.Fatalf("got %+v want %s", a, tc.kind)
			}
		})
	}
}

func TestV2LoginAndJSMeanReachable(t *testing.T) {
	for _, kind := range []string{"login", "js"} {
		result, _ := Decision([]Attempt{{Kind: kind}}, nil)
		if result != "否" {
			t.Errorf("%s: %s", kind, result)
		}
	}
}

func TestV2DetailedExportIncludesFinalURLAndStatus(t *testing.T) {
	rows := []Row{{Input: "https://original.example", URL: "https://original.example", Direct: []Attempt{{Kind: "usable", Status: 200, FinalURL: "https://destination.example/content"}}}}
	csv := string(ExportCSV(rows, true))
	for _, want := range []string{"大陆网络", "境外网络", "对照结论", "200", "https://destination.example/content"} {
		if !strings.Contains(csv, want) {
			t.Errorf("missing %s", want)
		}
	}
}
