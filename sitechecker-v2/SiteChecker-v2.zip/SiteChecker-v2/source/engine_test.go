package main

import (
	"context"
	"crypto/x509"
	"encoding/csv"
	"io"
	"net"
	"net/http"
	"net/http/httptest"
	"strings"
	"sync/atomic"
	"testing"
	"time"
)

func TestParseListPreservesRowsAndDuplicates(t *testing.T) {
	rows := ParseList("example.com\nhttps://example.com/jobs/?p=2\nexample.com\nnot a valid site\n\n[站点](https://example.org/a)")
	if len(rows) != 5 {
		t.Fatalf("got %d rows", len(rows))
	}
	if rows[0].URL != "https://example.com" || rows[2].URL != rows[0].URL {
		t.Fatalf("normalization/order: %#v", rows)
	}
	if rows[3].Error == "" || rows[4].URL != "https://example.org/a" {
		t.Fatal(rows)
	}
}
func TestUnsafeAndInvalidURLsRejected(t *testing.T) {
	for _, v := range []string{"file:///etc/passwd", "javascript:alert(1)", "https://u:secret@example.com", "http://", "example", "https://bad host.com"} {
		if _, err := Normalize(v); err == nil {
			t.Errorf("accepted %q", v)
		}
	}
}
func TestDecisionEvidenceMatrix(t *testing.T) {
	network := []Attempt{{Kind: "transport"}, {Kind: "transport"}, {Kind: "transport"}}
	ok2 := []Attempt{{Kind: "usable"}, {Kind: "usable"}}
	cases := []struct {
		name          string
		direct, proxy []Attempt
		want          string
	}{
		{"direct success", []Attempt{{Kind: "usable"}}, nil, "否"},
		{"repeat network failure with comparison", network, ok2, "是"},
		{"no comparison", network, nil, "待确认"},
		{"single comparison", network, ok2[:1], "待确认"},
		{"incomplete direct", network[:2], ok2, "待确认"},
		{"HTTP rejection", []Attempt{{Kind: "http"}, {Kind: "transport"}, {Kind: "transport"}}, ok2, "待确认"},
		{"certificate failure", []Attempt{{Kind: "tls"}, {Kind: "tls"}, {Kind: "tls"}}, ok2, "待确认"},
		{"challenge in proxy", network, []Attempt{{Kind: "challenge"}, {Kind: "challenge"}}, "待确认"},
		{"both failed", network, network, "待确认"},
		{"cancelled", []Attempt{{Kind: "cancelled"}}, ok2, "待确认"},
	}
	for _, c := range cases {
		t.Run(c.name, func(t *testing.T) {
			got, _ := Decision(c.direct, c.proxy)
			if got != c.want {
				t.Fatalf("got %s want %s", got, c.want)
			}
		})
	}
}
func TestProbeHTTPResponsesAndRedirects(t *testing.T) {
	content := "<html><head><title>Research</title></head><body>" + strings.Repeat("Research article and market information. ", 30) + "</body></html>"
	mux := http.NewServeMux()
	mux.HandleFunc("/ok", func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "text/html")
		io.WriteString(w, content)
	})
	mux.HandleFunc("/redirect", func(w http.ResponseWriter, r *http.Request) { http.Redirect(w, r, "/ok", 302) })
	mux.HandleFunc("/deny", func(w http.ResponseWriter, r *http.Request) { w.WriteHeader(403) })
	mux.HandleFunc("/down", func(w http.ResponseWriter, r *http.Request) { w.WriteHeader(503) })
	mux.HandleFunc("/captcha", func(w http.ResponseWriter, r *http.Request) {
		io.WriteString(w, "<html><title>Just a moment...</title><body>"+content+"<script src='/cdn-cgi/challenge-platform/x'></script></body></html>")
	})
	mux.HandleFunc("/shell", func(w http.ResponseWriter, r *http.Request) {
		io.WriteString(w, "<html><body><div id='app'></div><script src='bundle.js'></script></body></html>")
	})
	mux.HandleFunc("/empty", func(w http.ResponseWriter, r *http.Request) { w.WriteHeader(200) })
	mux.HandleFunc("/login", func(w http.ResponseWriter, r *http.Request) { io.WriteString(w, content) })
	s := httptest.NewServer(mux)
	defer s.Close()
	for path, want := range map[string]string{"/ok": "usable", "/redirect": "usable", "/deny": "http", "/down": "http", "/captcha": "challenge", "/shell": "js", "/empty": "empty", "/login": "login"} {
		a := Probe(context.Background(), s.Client(), s.URL+path)
		if a.Kind != want {
			t.Errorf("%s got %s (%s), want %s", path, a.Kind, a.Note, want)
		}
	}
}
func TestTimeoutAndCertificateAreDifferent(t *testing.T) {
	s := httptest.NewTLSServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) { io.WriteString(w, "ok") }))
	defer s.Close()
	c := &http.Client{Timeout: time.Second}
	a := Probe(context.Background(), c, s.URL)
	if a.Kind != "tls" {
		t.Fatalf("TLS classified %s: %s", a.Kind, a.Note)
	}
	slow := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) { <-r.Context().Done() }))
	defer slow.Close()
	c.Timeout = 40 * time.Millisecond
	a = Probe(context.Background(), c, slow.URL)
	if a.Kind != "transport" {
		t.Fatalf("timeout classified %s", a.Kind)
	}
	ctx, cancel := context.WithCancel(context.Background())
	cancel()
	a = Probe(ctx, c, slow.URL)
	if a.Kind != "cancelled" {
		t.Fatal(a)
	}
}
func TestCheckRetriesAndProxyRequiresTwoSuccesses(t *testing.T) {
	var calls int
	s := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		calls++
		w.Header().Set("Content-Type", "text/plain")
		io.WriteString(w, strings.Repeat("Market information. ", 20))
	}))
	defer s.Close()
	got := Check(context.Background(), s.Client(), s.URL, 2, 2, 0)
	if len(got) != 2 || calls != 2 {
		t.Fatalf("comparison calls %d attempts %d", calls, len(got))
	}
	calls = 0
	got = Check(context.Background(), s.Client(), s.URL, 3, 1, 0)
	if len(got) != 1 || calls != 1 {
		t.Fatal(calls, got)
	}
}
func TestCSVOrderEscapingAndFormulaSafety(t *testing.T) {
	rows := []Row{{Input: "=1+1", URL: "https://example.com", Direct: []Attempt{{Kind: "usable"}}}, {Input: "a,\"b", Error: "输入无效"}}
	b := ExportCSV(rows, false)
	if !strings.HasPrefix(string(b), "\xef\xbb\xbf") {
		t.Fatal("missing BOM")
	}
	records, err := csv.NewReader(strings.NewReader(strings.TrimPrefix(string(b), "\xef\xbb\xbf"))).ReadAll()
	if err != nil {
		t.Fatal(err)
	}
	if len(records) != 3 || len(records[0]) != 4 || records[1][3] != "大陆可打开" || records[2][3] != "待确认" {
		t.Fatal(records)
	}
	detail := string(ExportCSV(rows, true))
	if !strings.Contains(detail, "'=1+1") {
		t.Fatal("unsafe formula", detail)
	}
}
func TestExplicitProxyOverridesEnvironment(t *testing.T) {
	t.Setenv("HTTP_PROXY", "http://127.0.0.1:1")
	direct, err := NewClient("", time.Second)
	if err != nil {
		t.Fatal(err)
	}
	tr := direct.Transport.(*http.Transport)
	if tr.Proxy != nil {
		t.Fatal("direct client inherited proxy")
	}
	proxied, err := NewClient("socks5://127.0.0.1:7890", time.Second)
	if err != nil {
		t.Fatal(err)
	}
	req, _ := http.NewRequest("GET", "https://example.com", nil)
	p, err := proxied.Transport.(*http.Transport).Proxy(req)
	if err != nil || p.String() != "socks5://127.0.0.1:7890" {
		t.Fatal(p, err)
	}
	if _, err = NewClient("ftp://localhost:1", time.Second); err == nil {
		t.Fatal("accepted invalid proxy")
	}
}

func TestCancellationAfterHeadersIsNotNetworkEvidence(t *testing.T) {
	headers := make(chan struct{})
	reading := make(chan struct{})
	s := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "text/plain")
		io.WriteString(w, "partial")
		w.(http.Flusher).Flush()
		close(headers)
		<-r.Context().Done()
	}))
	defer s.Close()
	ctx, cancel := context.WithCancel(context.Background())
	done := make(chan Attempt, 1)
	client := &http.Client{Transport: roundTripFunc(func(r *http.Request) (*http.Response, error) {
		response, err := http.DefaultTransport.RoundTrip(r)
		if err == nil {
			response.Body = &notifyingReadCloser{ReadCloser: response.Body, started: reading}
		}
		return response, err
	})}
	go func() { done <- Probe(ctx, client, s.URL) }()
	<-headers
	<-reading
	cancel()
	a := <-done
	if a.Kind != "cancelled" {
		t.Fatalf("cancel after headers classified %s", a.Kind)
	}
	result, _ := Decision([]Attempt{{Kind: "transport"}, {Kind: "transport"}, a}, []Attempt{{Kind: "usable"}, {Kind: "usable"}})
	if result != "待确认" {
		t.Fatalf("cancelled baseline became %s", result)
	}
}
func TestLoginFormAtRootIsNotContentSuccess(t *testing.T) {
	s := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "text/html")
		io.WriteString(w, "<html><title>Account</title><body>"+strings.Repeat("Please log in to access the research information. ", 10)+"<form><input name='email'><input TYPE = 'PASSWORD'></form></body></html>")
	}))
	defer s.Close()
	a := Probe(context.Background(), s.Client(), s.URL)
	if a.Kind != "login" {
		t.Fatalf("login at root became %s", a.Kind)
	}
}
func TestResultCSVIsNotAdvertisedAsRawTextImport(t *testing.T) {
	if strings.Contains(indexHTML, "导入 TXT / CSV") || strings.Contains(indexHTML, `accept=".txt,.csv`) {
		t.Fatal("CSV import advertised without parser")
	}
}

type roundTripFunc func(*http.Request) (*http.Response, error)

func (f roundTripFunc) RoundTrip(r *http.Request) (*http.Response, error) { return f(r) }

type notifyingReadCloser struct {
	io.ReadCloser
	started  chan struct{}
	notified bool
}

func (n *notifyingReadCloser) Read(b []byte) (int, error) {
	if !n.notified {
		n.notified = true
		close(n.started)
	}
	return n.ReadCloser.Read(b)
}

func TestHTTPSConnectProxyUsesExplicitRoute(t *testing.T) {
	target := httptest.NewTLSServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "text/plain")
		io.WriteString(w, strings.Repeat("TLS target content. ", 30))
	}))
	defer target.Close()
	var tunnels atomic.Int32
	proxy := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if r.Method != "CONNECT" {
			t.Errorf("expected CONNECT, got %s", r.Method)
			w.WriteHeader(400)
			return
		}
		upstream, err := net.Dial("tcp", r.Host)
		if err != nil {
			w.WriteHeader(502)
			return
		}
		downstream, _, err := w.(http.Hijacker).Hijack()
		if err != nil {
			upstream.Close()
			return
		}
		tunnels.Add(1)
		downstream.Write([]byte("HTTP/1.1 200 Connection Established\r\n\r\n"))
		go func() { defer upstream.Close(); defer downstream.Close(); io.Copy(upstream, downstream) }()
		io.Copy(downstream, upstream)
	}))
	defer proxy.Close()
	client, err := NewClient(proxy.URL, time.Second)
	if err != nil {
		t.Fatal(err)
	}
	defer client.CloseIdleConnections()
	// Trust only the local test certificate; production always uses OS root certificates.
	roots := x509.NewCertPool()
	roots.AddCert(target.Certificate())
	client.Transport.(*http.Transport).TLSClientConfig.RootCAs = roots
	a := Probe(context.Background(), client, target.URL)
	if a.Kind != "usable" || tunnels.Load() != 1 {
		t.Fatalf("HTTPS tunnel failed %+v, tunnels %d", a, tunnels.Load())
	}
}
