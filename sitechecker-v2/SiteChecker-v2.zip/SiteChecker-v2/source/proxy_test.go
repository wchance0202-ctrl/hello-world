package main

import (
	"context"
	"net/http"
	"net/http/httptest"
	"testing"
	"time"
)

func TestV2ProxySelectionFollowsRequestScheme(t *testing.T) {
	c, e := NewClient("http=127.0.0.1:8011;https=127.0.0.1:8012", time.Second)
	if e != nil {
		t.Fatal(e)
	}
	for _, tc := range []struct{ u, want string }{{"http://example.com", "http://127.0.0.1:8011"}, {"https://example.com", "http://127.0.0.1:8012"}} {
		r, _ := http.NewRequest("GET", tc.u, nil)
		p, e := c.Transport.(*http.Transport).Proxy(r)
		if e != nil || p.String() != tc.want {
			t.Fatalf("%s: %v %v", tc.u, p, e)
		}
	}
}
func TestV2ProxyDoesNotSilentlyFallBackToDirect(t *testing.T) {
	c, e := NewClient("https=127.0.0.1:8012", time.Second)
	if e != nil {
		t.Fatal(e)
	}
	r, _ := http.NewRequest("GET", "http://example.com", nil)
	if _, e = c.Transport.(*http.Transport).Proxy(r); e == nil {
		t.Fatal("unconfigured HTTP route should fail clearly")
	}
}
func TestV2StableHTTPStopsRetries(t *testing.T) {
	n := 0
	s := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) { n++; w.WriteHeader(403) }))
	defer s.Close()
	got := Check(context.Background(), s.Client(), s.URL, 3, 1, 0)
	if len(got) != 1 || n != 1 {
		t.Fatal(len(got), n)
	}
}
