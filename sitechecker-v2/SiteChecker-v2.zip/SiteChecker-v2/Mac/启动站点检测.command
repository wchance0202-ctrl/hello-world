#!/bin/bash
set -eu
app_root="$(cd -- "$(dirname -- "$0")" && pwd)"
case "$(uname -m)" in
  arm64) app_binary="$app_root/AppleSilicon/SiteChecker" ;;
  x86_64) app_binary="$app_root/Intel/SiteChecker" ;;
  *) echo '不支持的 Mac 处理器'; exit 1 ;;
esac
chmod u+x "$app_binary"
exec "$app_binary"
