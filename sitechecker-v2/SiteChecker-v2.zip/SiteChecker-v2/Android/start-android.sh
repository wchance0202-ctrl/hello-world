#!/data/data/com.termux/files/usr/bin/bash
set -eu
package_root=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
if ! command -v go >/dev/null 2>&1 || ! command -v clang >/dev/null 2>&1; then
  echo '请先在 Termux 执行：pkg update && pkg install golang clang'
  exit 1
fi
app_build_dir="$HOME/.cache/sitechecker-v2"
mkdir -p "$app_build_dir"
cd "$package_root/source"
printf '%s\n' '正在本机编译；首次启动需要一些时间。源码依赖已包含，无需额外下载 Go 模块。'
CGO_ENABLED=1 GOTOOLCHAIN=local go build -mod=vendor -buildvcs=false -o "$app_build_dir/SiteChecker" .
printf '%s\n' '正在启动。浏览器未打开时，请复制下面显示的本机地址。'
exec "$app_build_dir/SiteChecker"
