安卓独立检测方案：Termux + 手机本地程序

1. 从官方说明中的可信渠道安装 Termux：
   https://github.com/termux/termux-app#installation
   不需要电脑或 root。保持 Termux 在后台运行，浏览器使用本机界面。
2. 在 Termux 执行：
   pkg update
   pkg install golang clang
   termux-setup-storage
   系统询问存储权限时允许，以便读取你下载、解压的文件。
3. 将整个 SiteChecker-v2 文件夹解压到手机 Download 文件夹。
4. 在 Termux 执行（大小写与解压后的目录一致）：
   bash ~/storage/downloads/SiteChecker-v2/Android/start-android.sh
   若使用其他解压目录，请替换路径。
5. 首次会用手机上的 Go 编译，之后打开默认浏览器；未自动打开时复制终端显示的
   http://127.0.0.1:端口/随机路径/ 到手机浏览器。
6. 按页面先关闭 VPN 测大陆，再开启境外全局 VPN 测境外。
   代理模式推荐“全局 VPN/TUN”，确保 VPN 的应用范围包含 Termux；
   若使用本地 HTTP/SOCKS5 代理，填写代理软件显示的实际端口。

注意
不要只复制 Android 目录，需要保留旁边 source 目录。
同一 Go 检测引擎在手机本地运行。使用 CGO 连接 Android 系统 DNS 解析，
首次需安装 Go 和 Clang；依赖源码已包含，不再从 Go 模块服务下载第三方库。
Go版本至少1.26。若仓库提供版本过旧，请更新可信 Termux 软件源或稍后重试。
编译产物放在 Termux 的 ~/.cache/sitechecker-v2，不在共享 Download 目录执行。
Android 的省电/后台限制可能结束 Termux；建议小批量检测并保持应用运行。
检测结束及时导出 CSV；关闭进程后结果不保留。
本包不提供 APK，也没有在真实安卓手机上实测；第一次先用少量网址验证。
